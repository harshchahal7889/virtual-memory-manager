-- ============================================================
-- Stock Trading Simulation System - Database Setup
-- Run this file in MySQL before starting the application
-- ============================================================

CREATE DATABASE IF NOT EXISTS stock_trading_db;
USE stock_trading_db;

-- ============================================================
-- USERS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    balance DECIMAL(15, 2) NOT NULL DEFAULT 100000.00,
    role ENUM('USER', 'ADMIN') NOT NULL DEFAULT 'USER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- STOCKS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS stocks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    symbol VARCHAR(10) NOT NULL UNIQUE,
    company_name VARCHAR(100) NOT NULL,
    current_price DECIMAL(10, 2) NOT NULL,
    previous_price DECIMAL(10, 2) NOT NULL,
    sector VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================================
-- PORTFOLIO TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS portfolio (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    stock_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 0,
    average_buy_price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (stock_id) REFERENCES stocks(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_stock (user_id, stock_id)
);

-- ============================================================
-- TRANSACTIONS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    stock_id INT NOT NULL,
    transaction_type ENUM('BUY', 'SELL') NOT NULL,
    quantity INT NOT NULL,
    price_per_share DECIMAL(10, 2) NOT NULL,
    total_amount DECIMAL(15, 2) NOT NULL,
    transaction_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (stock_id) REFERENCES stocks(id) ON DELETE CASCADE
);

-- ============================================================
-- PRICE HISTORY TABLE (for graphs)
-- ============================================================
CREATE TABLE IF NOT EXISTS price_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    stock_id INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (stock_id) REFERENCES stocks(id) ON DELETE CASCADE
);

-- ============================================================
-- SEED DATA: Default Admin User
-- Password: admin123
-- ============================================================
INSERT IGNORE INTO users (username, password, email, balance, role)
VALUES ('admin', 'admin123', 'admin@stocktrading.com', 999999999.00, 'ADMIN');

-- ============================================================
-- SEED DATA: Demo User
-- Password: demo123
-- ============================================================
INSERT IGNORE INTO users (username, password, email, balance, role)
VALUES ('demo', 'demo123', 'demo@stocktrading.com', 100000.00, 'USER');

-- ============================================================
-- SEED DATA: Preloaded Stocks
-- ============================================================
INSERT IGNORE INTO stocks (symbol, company_name, current_price, previous_price, sector) VALUES
('AAPL',  'Apple Inc.',                  178.50,  176.20, 'Technology'),
('GOOGL', 'Alphabet Inc.',               141.80,  139.50, 'Technology'),
('MSFT',  'Microsoft Corporation',       415.30,  412.00, 'Technology'),
('AMZN',  'Amazon.com Inc.',             185.20,  183.70, 'E-Commerce'),
('TSLA',  'Tesla Inc.',                  248.50,  252.10, 'Automotive'),
('META',  'Meta Platforms Inc.',         505.80,  498.30, 'Social Media'),
('NVDA',  'NVIDIA Corporation',          875.40,  868.20, 'Semiconductors'),
('NFLX',  'Netflix Inc.',               625.70,  618.90, 'Entertainment'),
('JPM',   'JPMorgan Chase & Co.',        198.30,  196.80, 'Finance'),
('BAC',   'Bank of America Corp.',        38.75,   38.20, 'Finance'),
('V',     'Visa Inc.',                   278.60,  276.40, 'Finance'),
('JNJ',   'Johnson & Johnson',           152.40,  153.10, 'Healthcare'),
('PFE',   'Pfizer Inc.',                  27.80,   28.10, 'Healthcare'),
('WMT',   'Walmart Inc.',               193.50,  191.20, 'Retail'),
('DIS',   'The Walt Disney Company',      97.30,   96.80, 'Entertainment'),
('PYPL',  'PayPal Holdings Inc.',         66.90,   67.40, 'Fintech'),
('UBER',  'Uber Technologies Inc.',       78.20,   77.50, 'Transportation'),
('SPOT',  'Spotify Technology S.A.',     255.30,  252.80, 'Entertainment'),
('COIN',  'Coinbase Global Inc.',        220.40,  218.90, 'Crypto/Finance'),
('AMD',   'Advanced Micro Devices',      168.70,  172.30, 'Semiconductors');

-- ============================================================
-- INDEX for performance
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_price_history_stock ON price_history(stock_id, recorded_at);
CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id, transaction_time);
CREATE INDEX IF NOT EXISTS idx_portfolio_user ON portfolio(user_id);

SELECT 'Database setup complete!' AS Status;
