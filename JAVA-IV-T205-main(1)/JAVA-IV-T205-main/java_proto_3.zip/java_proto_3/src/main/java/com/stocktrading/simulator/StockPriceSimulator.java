package com.stocktrading.simulator;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import com.stocktrading.model.Stock;
import com.stocktrading.service.StockService;

/**
 * StockPriceSimulator
 * ───────────────────
 * Runs on a background daemon thread. Every 2–4 seconds it picks all stocks,
 * applies a random ±1% change to each price, persists to DB, then notifies
 * registered listeners so the UI can update without polling.
 *
 * Thread-safety: DB writes are in the service layer which uses synchronized
 * JDBC. Listeners are called via SwingUtilities.invokeLater()
 * by the UI layer (not here) so this class stays Swing-free.
 */
public class StockPriceSimulator {

    private static final int MIN_DELAY_MS = 15000;
    private static final int MAX_DELAY_MS = 15000; // maximum interval
    private static final double MAX_CHANGE_PCT = 0.01; // ±1%

    private final StockService stockService;
    private final Random random = new Random();
    private final ScheduledExecutorService scheduler;

    // Listeners receive the updated stock after each price tick
    private final List<Consumer<Stock>> listeners = new CopyOnWriteArrayList<>();

    private volatile boolean running = false;

    public StockPriceSimulator(StockService stockService) {
        this.stockService = stockService;
        this.scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "StockSimulator-Thread");
            t.setDaemon(true); // dies with the JVM
            return t;
        });
    }

    /** Starts the price simulation loop. */
    public void start() {
        if (running)
            return;
        running = true;
        scheduleNext();
        System.out.println("[Simulator] Price simulation started.");
    }

    /** Stops the simulation loop gracefully. */
    public void stop() {
        running = false;
        scheduler.shutdownNow();
        System.out.println("[Simulator] Price simulation stopped.");
    }

    /** Registers a callback to be invoked after each stock's price is updated. */
    public void addListener(Consumer<Stock> listener) {
        listeners.add(listener);
    }

    /** Removes a previously registered callback. */
    public void removeListener(Consumer<Stock> listener) {
        listeners.remove(listener);
    }

    // ── Internal ──────────────────────────────────────────────────────────────

    private void scheduleNext() {
        if (!running)
            return;
        // Randomise the delay between MIN and MAX
        int delay = MIN_DELAY_MS + random.nextInt(MAX_DELAY_MS - MIN_DELAY_MS + 1);
        scheduler.schedule(this::tick, delay, TimeUnit.MILLISECONDS);
    }

    /**
     * One simulation tick:
     * 1. Load all stocks from DB
     * 2. Apply random ±1% change
     * 3. Persist new price to DB
     * 4. Notify listeners
     * 5. Schedule the next tick
     */
    private void tick() {
        try {
            List<Stock> stocks = stockService.getAllStocks();
            for (Stock stock : stocks) {
                BigDecimal oldPrice = stock.getCurrentPrice();

                // Random change factor in [-1%, +1%]
                double changeFactor = (random.nextDouble() * 2 - 1) * MAX_CHANGE_PCT;
                BigDecimal newPrice = oldPrice
                        .multiply(BigDecimal.valueOf(1 + changeFactor))
                        .setScale(2, RoundingMode.HALF_UP);

                // Floor at $0.01 to avoid zero/negative prices
                if (newPrice.compareTo(BigDecimal.valueOf(0.01)) < 0) {
                    newPrice = BigDecimal.valueOf(0.01);
                }

                // Persist to DB
                boolean updated = stockService.updatePriceSimulated(stock.getId(), newPrice);
                if (updated) {
                    stock.setPreviousPrice(oldPrice);
                    stock.setCurrentPrice(newPrice);
                    notifyListeners(stock);
                }
            }
        } catch (Exception e) {
            System.err.println("[Simulator] Error during tick: " + e.getMessage());
        } finally {
            scheduleNext();
        }
    }

    private void notifyListeners(Stock stock) {
        for (Consumer<Stock> listener : listeners) {
            try {
                listener.accept(stock);
            } catch (Exception ignored) {
            }
        }
    }
}
