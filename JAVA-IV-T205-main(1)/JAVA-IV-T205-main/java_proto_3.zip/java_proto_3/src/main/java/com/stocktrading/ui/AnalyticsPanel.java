package com.stocktrading.ui;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

import com.stocktrading.model.Stock;
import com.stocktrading.service.StockService;
import com.stocktrading.simulator.StockPriceSimulator;

/**
 * AnalyticsPanel - Real-time stock chart using JFreeChart.
 *
 * Architecture:
 * - One TimeSeriesCollection per stock (lazy-created on first tick).
 * - A combo box lets the user switch which stock is shown.
 * - Price history is loaded from database on stock selection.
 * - Each price tick from StockPriceSimulator appends a new (Second, price) point.
 * - UI updates happen on the Swing EDT via SwingUtilities.invokeLater().
 * - JFreeChart handles rendering automatically on repaint.
 */
public class AnalyticsPanel extends JPanel {

    private final StockService stockService;
    private final StockPriceSimulator simulator;

    // One TimeSeries per stock ID (thread-safe map)
    private final Map<Integer, TimeSeries> seriesMap = new ConcurrentHashMap<>();

    // Currently displayed stock
    private volatile Stock currentStock;

    // UI components
    private JComboBox<Stock> stockCombo;
    private JLabel lblPrice, lblChange, lblPct, lblIndicator;
    private ChartPanel chartPanel;
    private TimeSeriesCollection dataset;
    private JFreeChart chart;
    private JPanel topGainersPanel, topLosersPanel;
    private boolean isUserInteracting = false;

    public AnalyticsPanel(StockService ss, StockPriceSimulator sim) {
        this.stockService = ss;
        this.simulator = sim;
        setLayout(new BorderLayout(0, 0));
        setBackground(UITheme.BG_DARK);
        buildUI();
    }

    private void buildUI() {
        // ── Header ────────────────────────────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout(16, 0));
        header.setBackground(UITheme.BG_DARK);
        header.setBorder(BorderFactory.createEmptyBorder(20, 24, 12, 24));

        JLabel title = new JLabel("📈 Stock Analytics Dashboard");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_PRIMARY);

        stockCombo = new JComboBox<>();
        stockCombo.setBackground(UITheme.BG_CARD);
        stockCombo.setForeground(UITheme.TEXT_PRIMARY);
        stockCombo.setFont(UITheme.FONT_BODY);
        stockCombo.setPreferredSize(new Dimension(300, 34));
        stockCombo.setRenderer(new StockComboRenderer());
        stockCombo.addActionListener(e -> onComboChange());

        JPanel comboWrap = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        comboWrap.setBackground(UITheme.BG_DARK);
        comboWrap.add(UITheme.subLabel("Select Stock: "));
        comboWrap.add(stockCombo);

        header.add(title, BorderLayout.WEST);
        header.add(comboWrap, BorderLayout.EAST);

        // ── Stat bar ──────────────────────────────────────────────────────────
        JPanel statBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 24, 8));
        statBar.setBackground(UITheme.BG_PANEL);
        statBar.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, UITheme.BORDER_COLOR));

        lblIndicator = new JLabel("●");
        lblIndicator.setFont(new Font("Segoe UI", Font.PLAIN, 22));
        lblIndicator.setForeground(UITheme.TEXT_MUTED);

        lblPrice = new JLabel("$—");
        lblPrice.setFont(new Font("JetBrains Mono", Font.BOLD, 26));
        lblPrice.setForeground(UITheme.TEXT_PRIMARY);

        lblChange = new JLabel("—");
        lblChange.setFont(UITheme.FONT_MONO_B);
        lblChange.setForeground(UITheme.TEXT_SECONDARY);

        lblPct = new JLabel("—");
        lblPct.setFont(UITheme.FONT_MONO_B);
        lblPct.setForeground(UITheme.TEXT_SECONDARY);

        statBar.add(lblIndicator);
        statBar.add(lblPrice);
        statBar.add(new JLabel(" │ ") {
            {
                setForeground(UITheme.TEXT_MUTED);
            }
        });
        statBar.add(UITheme.subLabel("Change: "));
        statBar.add(lblChange);
        statBar.add(new JLabel(" │ ") {
            {
                setForeground(UITheme.TEXT_MUTED);
            }
        });
        statBar.add(UITheme.subLabel("% Change: "));
        statBar.add(lblPct);

        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(UITheme.BG_DARK);
        top.add(header, BorderLayout.NORTH);
        top.add(statBar, BorderLayout.SOUTH);

        // ── Chart ─────────────────────────────────────────────────────────────
        dataset = new TimeSeriesCollection();
        chart = createChart(dataset);
        chartPanel = new ChartPanel(chart);
        chartPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                isUserInteracting = true;
            }

            @Override
            public void mouseReleased(java.awt.event.MouseEvent e) {
                isUserInteracting = false;
            }
        });
        chartPanel.setBackground(UITheme.BG_DARK);
        chartPanel.setPreferredSize(new Dimension(800, 400));
        chartPanel.setMouseWheelEnabled(true);

        // ── Side panel (gainers / losers) ─────────────────────────────────────
        JPanel side = new JPanel(new GridLayout(2, 1, 0, 8));
        side.setBackground(UITheme.BG_DARK);
        side.setBorder(BorderFactory.createEmptyBorder(8, 0, 8, 12));
        side.setPreferredSize(new Dimension(220, 0));

        topGainersPanel = buildRankPanel("🟢 Top Gainers");
        topLosersPanel = buildRankPanel("🔴 Top Losers");
        side.add(topGainersPanel);
        side.add(topLosersPanel);

        JPanel center = new JPanel(new BorderLayout(8, 0));
        center.setBackground(UITheme.BG_DARK);
        center.add(chartPanel, BorderLayout.CENTER);
        center.add(side, BorderLayout.EAST);

        add(top, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);
    }

    // ── JFreeChart factory ────────────────────────────────────────────────────

    private JFreeChart createChart(TimeSeriesCollection dataset) {
        JFreeChart c = ChartFactory.createTimeSeriesChart(
                null, // title
                "Time", // x-axis label
                "Price (USD)", // y-axis label
                dataset,
                false, // legend
                true, // tooltips
                false // URLs
        );

        // Dark theme styling
        c.setBackgroundPaint(UITheme.BG_DARK);
        c.setBorderVisible(false);

        XYPlot plot = c.getXYPlot();
        plot.setBackgroundPaint(UITheme.BG_CARD);
        plot.setDomainGridlinePaint(UITheme.BORDER_COLOR);
        plot.setRangeGridlinePaint(UITheme.BORDER_COLOR);
        plot.setOutlineVisible(false);
        plot.setDomainCrosshairVisible(true);
        plot.setRangeCrosshairVisible(true);
        plot.setDomainCrosshairPaint(UITheme.TEXT_MUTED);
        plot.setRangeCrosshairPaint(UITheme.TEXT_MUTED);

        // Axes
        DateAxis domainAxis = new DateAxis("Time");
        domainAxis.setTickLabelPaint(UITheme.TEXT_SECONDARY);
        domainAxis.setLabelPaint(UITheme.TEXT_PRIMARY);
        plot.setDomainAxis(domainAxis);

        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setTickLabelPaint(UITheme.TEXT_SECONDARY);
        rangeAxis.setLabelPaint(UITheme.TEXT_PRIMARY);
        plot.setRangeAxis(rangeAxis);

        // Renderer – smooth blue line
        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(true, false);
        renderer.setSeriesPaint(0, UITheme.ACCENT_BLUE);
        renderer.setSeriesStroke(0, new BasicStroke(2.2f));
        plot.setRenderer(renderer);

        return c;
    }

    /**
     * Sets the selected stock and loads its full price history from the database.
     * This is called when a stock is selected in TradingPanel or AnalyticsPanel.
     */
    public void setSelectedStock(Stock stock) {
        if (stock == null)
            return;

        // Prevent reloading the same stock
        if (currentStock != null && currentStock.getId() == stock.getId()) {
            return;
        }

        this.currentStock = stock;

        // Clear previous graph data
        dataset.removeAllSeries();
        seriesMap.clear();

        // Create new TimeSeries for this stock
        TimeSeries series = new TimeSeries(stock.getSymbol());
        series.setMaximumItemCount(500); // Allow more data points from DB

        try {
            // Load complete price history from database
            List<Object[]> history = stockService.getPriceHistory(stock.getId());

            if (history != null && !history.isEmpty()) {
                // Add all historical data points in chronological order
                for (Object[] row : history) {
                    try {
                        Timestamp time = (Timestamp) row[0];
                        double price = ((Number) row[1]).doubleValue();

                        // Convert Timestamp to Millisecond for JFreeChart
                        series.addOrUpdate(
                                new Millisecond(new java.util.Date(time.getTime())),
                                price
                        );
                    } catch (Exception e) {
                        // Skip malformed data points
                        continue;
                    }
                }
            } else {
                // If no history, add current price as starting point
                series.addOrUpdate(new Second(), stock.getCurrentPrice().doubleValue());
            }
        } catch (Exception e) {
            System.err.println("Error loading price history for stock " + stock.getSymbol() + ": " + e.getMessage());
            // Fallback: add current price
            series.addOrUpdate(new Second(), stock.getCurrentPrice().doubleValue());
        }

        // Add series to dataset
        dataset.addSeries(series);
        seriesMap.put(stock.getId(), series);

        // Update UI
        updateStatBar(stock);
        
        // Update chart title and colors
        XYPlot plot = chart.getXYPlot();
        XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, stock.isPriceUp() ? UITheme.GREEN_UP : UITheme.ACCENT_BLUE);
        chart.setTitle(stock.getSymbol() + " — " + stock.getCompanyName());
        chart.getTitle().setPaint(UITheme.TEXT_PRIMARY);
        chart.getTitle().setFont(UITheme.FONT_HEADING);
    }

    // ── Gainers / Losers rank panels ──────────────────────────────────────────

    private JPanel buildRankPanel(String title) {
        JPanel panel = new JPanel(new BorderLayout(0, 4));
        panel.setBackground(UITheme.BG_PANEL);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER_COLOR),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)));
        JLabel hdr = UITheme.heading(title);
        panel.add(hdr, BorderLayout.NORTH);
        return panel;
    }

    private void updateRankPanels() {
        List<Stock> gainers = stockService.getTopGainers(5);
        List<Stock> losers = stockService.getTopLosers(5);
        fillRankPanel(topGainersPanel, gainers, true);
        fillRankPanel(topLosersPanel, losers, false);
    }

    private void fillRankPanel(JPanel panel, List<Stock> stocks, boolean isGainer) {
        // Remove old content below header
        if (panel.getComponentCount() > 1)
            panel.remove(panel.getComponent(1));

        JPanel list = new JPanel(new GridLayout(stocks.size(), 1, 0, 3));
        list.setBackground(panel.getBackground());
        for (Stock s : stocks) {
            double pct = s.getPercentageChange();
            JPanel row = new JPanel(new BorderLayout());
            row.setBackground(panel.getBackground());
            JLabel sym = new JLabel(s.getSymbol());
            sym.setFont(UITheme.FONT_MONO_B);
            sym.setForeground(UITheme.ACCENT_CYAN);
            JLabel val = new JLabel(String.format("%+.2f%%", pct));
            val.setFont(UITheme.FONT_SMALL);
            val.setForeground(isGainer ? UITheme.GREEN_UP : UITheme.RED_DOWN);
            row.add(sym, BorderLayout.WEST);
            row.add(val, BorderLayout.EAST);
            list.add(row);
        }
        panel.add(list, BorderLayout.CENTER);
        panel.revalidate();
        panel.repaint();
    }

    // ── Stock selection ───────────────────────────────────────────────────────

    private void onComboChange() {
        Stock selected = (Stock) stockCombo.getSelectedItem();
        if (selected == null)
            return;

        // Use setSelectedStock to load full price history
        setSelectedStock(selected);
    }

    private void updateStatBar(Stock s) {
        double pct = s.getPercentageChange();
        double change = s.getCurrentPrice().subtract(s.getPreviousPrice()).doubleValue();
        lblPrice.setText("$" + String.format("%.2f", s.getCurrentPrice()));
        lblChange.setText(String.format("%+.2f", change));
        lblChange.setForeground(UITheme.changeColor(pct));
        lblPct.setText(UITheme.changeArrow(pct) + String.format(" %+.2f%%", pct));
        lblPct.setForeground(UITheme.changeColor(pct));
        lblIndicator.setForeground(UITheme.changeColor(pct));
    }

    // ── Public hooks ──────────────────────────────────────────────────────────

    /**
     * Called every time a stock price changes (from simulator).
     * Appends new price point to the currently displayed stock's series.
     */
    public void onPriceUpdate(Stock updatedStock) {

        // Stop all updates during user interaction
        if (isUserInteracting)
            return;

        // Only process current stock (critical optimization)
        if (currentStock == null || currentStock.getId() != updatedStock.getId()) {
            return;
        }

        // Get existing series
        TimeSeries series = seriesMap.get(updatedStock.getId());
        if (series == null)
            return;

        // Add new point safely
        try {
            series.addOrUpdate(new Second(), updatedStock.getCurrentPrice().doubleValue());
        } catch (Exception ignored) {
        }

        // Update UI safely
        currentStock = updatedStock;

        SwingUtilities.invokeLater(() -> {
            updateStatBar(updatedStock);

            XYPlot plot = chart.getXYPlot();
            XYLineAndShapeRenderer r = (XYLineAndShapeRenderer) plot.getRenderer();
            r.setSeriesPaint(0,
                    updatedStock.isPriceUp() ? UITheme.GREEN_UP : UITheme.RED_DOWN);
        });

        // Occasionally update rank panels
        if (Math.random() < 0.1) {
            SwingUtilities.invokeLater(this::updateRankPanels);
        }
    }

    /** Called when the user switches to the Analytics tab. */
    public void onShow() {
        // Populate combo with latest stock list
        Stock prev = (Stock) stockCombo.getSelectedItem();
        stockCombo.removeAllItems();
        List<Stock> stocks = stockService.getAllStocks();
        stocks.forEach(stockCombo::addItem);
        // Re-select previously selected stock if possible
        if (prev != null) {
            stocks.stream().filter(s -> s.getId() == prev.getId())
                    .findFirst().ifPresent(stockCombo::setSelectedItem);
        } else if (!stocks.isEmpty()) {
            stockCombo.setSelectedIndex(0);
        }
        updateRankPanels();
    }

    // ── Combo renderer ────────────────────────────────────────────────────────

    private static class StockComboRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value,
                int index, boolean isSelected, boolean hasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, hasFocus);
            setBackground(isSelected ? UITheme.BG_HOVER : UITheme.BG_CARD);
            setForeground(UITheme.TEXT_PRIMARY);
            if (value instanceof Stock s) {
                setText(s.getSymbol() + "  —  " + s.getCompanyName());
            }
            return this;
        }
    }
}