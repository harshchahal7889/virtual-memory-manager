package com.stocktrading.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * User - POJO representing a registered user in the system.
 */
public class User {

    private int       id;
    private String    username;
    private String    password;
    private String    email;
    private BigDecimal balance;
    private String    role;          // "USER" or "ADMIN"
    private Timestamp createdAt;

    // ── Constructors ──────────────────────────────────────────────────────────
    public User() {}

    public User(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email    = email;
        this.balance  = new BigDecimal("100000.00");
        this.role     = "USER";
    }

    // ── Getters & Setters ─────────────────────────────────────────────────────
    public int       getId()        { return id; }
    public void      setId(int id)  { this.id = id; }

    public String    getUsername()              { return username; }
    public void      setUsername(String u)      { this.username = u; }

    public String    getPassword()              { return password; }
    public void      setPassword(String p)      { this.password = p; }

    public String    getEmail()                 { return email; }
    public void      setEmail(String e)         { this.email = e; }

    public BigDecimal getBalance()              { return balance; }
    public void       setBalance(BigDecimal b)  { this.balance = b; }

    public String    getRole()                  { return role; }
    public void      setRole(String r)          { this.role = r; }

    public Timestamp getCreatedAt()             { return createdAt; }
    public void      setCreatedAt(Timestamp t)  { this.createdAt = t; }

    public boolean   isAdmin()                  { return "ADMIN".equals(role); }

    @Override
    public String toString() {
        return "User{id=" + id + ", username='" + username + "', role='" + role + "', balance=" + balance + "}";
    }
}
