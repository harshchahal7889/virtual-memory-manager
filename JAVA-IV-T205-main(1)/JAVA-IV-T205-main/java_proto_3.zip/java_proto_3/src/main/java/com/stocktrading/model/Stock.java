package com.stocktrading.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;

/**
 * Stock - POJO representing a tradeable stock in the system.
 */
public class Stock {

    private int        id;
    private String     symbol;
    private String     companyName;
    private BigDecimal currentPrice;
    private BigDecimal previousPrice;
    private String     sector;
    private Timestamp  createdAt;
    private Timestamp  updatedAt;

    // ── Constructors ──────────────────────────────────────────────────────────
    public Stock() {}

    public Stock(String symbol, String companyName, BigDecimal currentPrice, String sector) {
        this.symbol        = symbol;
        this.companyName   = companyName;
        this.currentPrice  = currentPrice;
        this.previousPrice = currentPrice;
        this.sector        = sector;
    }

    // ── Business Logic ────────────────────────────────────────────────────────

    /**
     * Calculates the percentage price change from previousPrice to currentPrice.
     * @return e.g. +1.23 or -0.85
     */
    public double getPercentageChange() {
        if (previousPrice == null || previousPrice.compareTo(BigDecimal.ZERO) == 0) return 0.0;
        return currentPrice.subtract(previousPrice)
                .divide(previousPrice, 6, RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(100))
                .doubleValue();
    }

    /** Returns true if the current price is higher than the previous price. */
    public boolean isPriceUp() {
        return currentPrice.compareTo(previousPrice) > 0;
    }

    /** Returns true if the current price is lower than the previous price. */
    public boolean isPriceDown() {
        return currentPrice.compareTo(previousPrice) < 0;
    }

    // ── Getters & Setters ─────────────────────────────────────────────────────
    public int        getId()              { return id; }
    public void       setId(int id)        { this.id = id; }

    public String     getSymbol()           { return symbol; }
    public void       setSymbol(String s)   { this.symbol = s; }

    public String     getCompanyName()           { return companyName; }
    public void       setCompanyName(String n)   { this.companyName = n; }

    public BigDecimal getCurrentPrice()              { return currentPrice; }
    public void       setCurrentPrice(BigDecimal p)  { this.currentPrice = p; }

    public BigDecimal getPreviousPrice()               { return previousPrice; }
    public void       setPreviousPrice(BigDecimal p)   { this.previousPrice = p; }

    public String     getSector()            { return sector; }
    public void       setSector(String s)    { this.sector = s; }

    public Timestamp  getCreatedAt()                { return createdAt; }
    public void       setCreatedAt(Timestamp t)     { this.createdAt = t; }

    public Timestamp  getUpdatedAt()                { return updatedAt; }
    public void       setUpdatedAt(Timestamp t)     { this.updatedAt = t; }

    @Override
    public String toString() {
        return symbol + " (" + companyName + ") @ $" + currentPrice;
    }
}
