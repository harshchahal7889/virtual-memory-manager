package com.stocktrading.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * DatabaseConnection - Singleton pattern for managing JDBC connections.
 * Provides a single shared connection to the MySQL database.
 */
public class DatabaseConnection {

    // ── Configuration ────────────────────────────────────────────────────────
    private static final String HOST     = "127.0.0.1:3306";
    private static final String PORT     = "3306";
    private static final String DATABASE = "stock_trading_db";
    private static final String USERNAME = "root";        // ← Change as needed
    private static final String PASSWORD = "Tgksc@2005";        // ← Change as needed

    private static final String URL =
"jdbc:mysql://127.0.0.1:3306/stock_trading_db?useSSL=false&serverTimezone=UTC";

    // ── Singleton instance ────────────────────────────────────────────────────
    private static Connection connection = null;

    /** Private constructor – use getInstance() */
    private DatabaseConnection() {}

    /**
     * Returns the single shared Connection, creating it on first call.
     */
    public static Connection getInstance() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                System.out.println("[DB] Connected to MySQL successfully.");
            } catch (ClassNotFoundException e) {
                throw new SQLException("MySQL JDBC Driver not found. Add mysql-connector-java to classpath.", e);
            }
        }
        return connection;
    }

    /** Closes the shared connection (call on application exit). */
    public static void close() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("[DB] Connection closed.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
