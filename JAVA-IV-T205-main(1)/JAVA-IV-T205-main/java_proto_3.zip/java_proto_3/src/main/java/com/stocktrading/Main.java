package com.stocktrading;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import com.stocktrading.ui.LoginFrame;
import com.stocktrading.ui.UITheme;
import com.stocktrading.util.DatabaseConnection;

/**
 * Main - Application entry point.
 *
 * Launch order:
 *   1. Apply global Swing look-and-feel tweaks (dark theme defaults)
 *   2. Set Nimbus LAF base (optional, falls back to system LAF gracefully)
 *   3. Show the LoginFrame on the Swing Event Dispatch Thread
 *   4. Register a shutdown hook to close the DB connection cleanly
 */
public class Main {

    public static void main(String[] args) {

        // ── 1. Apply Nimbus as base LAF (cleaner rendering) ───────────────────
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            // Fall back to system LAF silently
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception ignored) {}
        }

        // ── 2. Apply our custom dark-theme defaults on top of Nimbus ─────────
        UITheme.applyGlobalDefaults();

        // ── 3. Register DB shutdown hook ──────────────────────────────────────
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("[Main] Shutting down — closing database connection.");
            DatabaseConnection.close();
        }));

        // ── 4. Launch UI on the Event Dispatch Thread ─────────────────────────
        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
        });
    }
}
