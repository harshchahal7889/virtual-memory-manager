package com.stocktrading.dao;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.stocktrading.model.Stock;
import com.stocktrading.util.DatabaseConnection;

/**
 * StockDAO - Data Access Object for the `stocks` table.
 * Handles CRUD operations and price updates for stocks.
 */
public class StockDAO {

    // ── Read ──────────────────────────────────────────────────────────────────

    /** Returns all stocks, ordered by symbol. */
    public List<Stock> findAll() throws SQLException {
        List<Stock> stocks = new ArrayList<>();
        String sql = "SELECT * FROM stocks ORDER BY symbol ASC";
        try (Statement st = DatabaseConnection.getInstance().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) stocks.add(mapRow(rs));
        }
        return stocks;
    }

    /** Fetches a single stock by its database ID. */
    public Stock findById(int id) throws SQLException {
        String sql = "SELECT * FROM stocks WHERE id = ?";
        try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        }
        return null;
    }

    /** Fetches a stock by its ticker symbol (e.g. "AAPL"). */
    public Stock findBySymbol(String symbol) throws SQLException {
        String sql = "SELECT * FROM stocks WHERE symbol = ?";
        try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
            ps.setString(1, symbol.toUpperCase());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        }
        return null;
    }

    // ── Create ────────────────────────────────────────────────────────────────

    /** Inserts a new stock into the database. Returns generated ID or -1. */
    public int addStock(Stock stock) throws SQLException {
        String sql = "INSERT INTO stocks (symbol, company_name, current_price, previous_price, sector) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = DatabaseConnection.getInstance()
                .prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, stock.getSymbol().toUpperCase());
            ps.setString(2, stock.getCompanyName());
            ps.setBigDecimal(3, stock.getCurrentPrice());
            ps.setBigDecimal(4, stock.getCurrentPrice()); // previous = current on creation
            ps.setString(5, stock.getSector());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) return keys.getInt(1);
        }
        return -1;
    }

    // ── Update ────────────────────────────────────────────────────────────────

    /**
     * Updates the stock price, keeping the previous_price for change tracking.
     * This is called by the admin panel AND by the StockPriceSimulator.
     */
    public boolean updatePrice(int stockId, BigDecimal newPrice) throws SQLException {
        String sql = "UPDATE stocks SET previous_price = current_price, current_price = ?, updated_at = NOW() WHERE id = ?";
        try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
            ps.setBigDecimal(1, newPrice);
            ps.setInt(2, stockId);
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Fetches complete price history for a stock from the price_history table.
     * Returns list of Object[] containing [Timestamp, double price] in chronological order.
     */
    public List<Object[]> getPriceHistory(int stockId) throws SQLException {
        List<Object[]> list = new ArrayList<>();
        String sql = "SELECT recorded_at, price FROM price_history WHERE stock_id = ? ORDER BY recorded_at ASC";

        try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
            ps.setInt(1, stockId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Timestamp time = rs.getTimestamp("recorded_at");
                double price = rs.getDouble("price");
                list.add(new Object[]{time, price});
            }
        }
        return list;
    }

    /** Full stock update (symbol, name, price, sector). */
    public boolean updateStock(Stock stock) throws SQLException {
        String sql = "UPDATE stocks SET symbol = ?, company_name = ?, previous_price = current_price, current_price = ?, sector = ? WHERE id = ?";
        try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
            ps.setString(1, stock.getSymbol().toUpperCase());
            ps.setString(2, stock.getCompanyName());
            ps.setBigDecimal(3, stock.getCurrentPrice());
            ps.setString(4, stock.getSector());
            ps.setInt(5, stock.getId());
            return ps.executeUpdate() > 0;
        }
    }

    // ── Delete ────────────────────────────────────────────────────────────────

    /** Deletes a stock by ID. Cascades to portfolio and transactions. */
    public boolean deleteStock(int stockId) throws SQLException {
        String sql = "DELETE FROM stocks WHERE id = ?";
        try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
            ps.setInt(1, stockId);
            return ps.executeUpdate() > 0;
        }
    }

    // ── Price History ─────────────────────────────────────────────────────────

    /**
     * Records a price data point into price_history (used for graph plotting).
     */
    public void recordPriceHistory(int stockId, BigDecimal price) throws SQLException {
        String sql = "INSERT INTO price_history (stock_id, price, recorded_at) VALUES (?, ?, NOW())";
        try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
            ps.setInt(1, stockId);
            ps.setBigDecimal(2, price);
            ps.executeUpdate();
        }
    }

    /**
     * Returns the last N price history entries for a stock (for graph seeding).
     * Returns list of double[] containing [timestamp in ms, price].
     */
    public List<double[]> getPriceHistoryLimit(int stockId, int limit) throws SQLException {
        List<double[]> history = new ArrayList<>();
        String sql = "SELECT UNIX_TIMESTAMP(recorded_at) * 1000 AS ts, price FROM price_history " +
                     "WHERE stock_id = ? ORDER BY recorded_at DESC LIMIT ?";
        try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
            ps.setInt(1, stockId);
            ps.setInt(2, limit);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                history.add(new double[]{ rs.getDouble("ts"), rs.getDouble("price") });
            }
        }
        return history;
    }

    // ── Analytics ─────────────────────────────────────────────────────────────

    /** Returns top N gainers sorted by percentage change descending. */
    public List<Stock> getTopGainers(int limit) throws SQLException {
        List<Stock> stocks = new ArrayList<>();
        String sql = "SELECT *, ((current_price - previous_price)/previous_price*100) AS pct " +
                     "FROM stocks ORDER BY pct DESC LIMIT ?";
        try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) stocks.add(mapRow(rs));
        }
        return stocks;
    }

    /** Returns top N losers sorted by percentage change ascending. */
    public List<Stock> getTopLosers(int limit) throws SQLException {
        List<Stock> stocks = new ArrayList<>();
        String sql = "SELECT *, ((current_price - previous_price)/previous_price*100) AS pct " +
                     "FROM stocks ORDER BY pct ASC LIMIT ?";
        try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) stocks.add(mapRow(rs));
        }
        return stocks;
    }

    // ── Mapping ───────────────────────────────────────────────────────────────

    private Stock mapRow(ResultSet rs) throws SQLException {
        Stock s = new Stock();
        s.setId(rs.getInt("id"));
        s.setSymbol(rs.getString("symbol"));
        s.setCompanyName(rs.getString("company_name"));
        s.setCurrentPrice(rs.getBigDecimal("current_price"));
        s.setPreviousPrice(rs.getBigDecimal("previous_price"));
        s.setSector(rs.getString("sector"));
        s.setCreatedAt(rs.getTimestamp("created_at"));
        s.setUpdatedAt(rs.getTimestamp("updated_at"));
        return s;
    }
}