package com.stocktrading.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * Transaction - POJO for a single BUY or SELL event.
 */
public class Transaction {

    private int        id;
    private int        userId;
    private int        stockId;
    private String     transactionType;   // "BUY" or "SELL"
    private int        quantity;
    private BigDecimal pricePerShare;
    private BigDecimal totalAmount;
    private Timestamp  transactionTime;

    // ── Extra display fields (joined from other tables) ───────────────────────
    private String     stockSymbol;
    private String     companyName;

    // ── Constructors ──────────────────────────────────────────────────────────
    public Transaction() {}

    public Transaction(int userId, int stockId, String type, int qty, BigDecimal price) {
        this.userId          = userId;
        this.stockId         = stockId;
        this.transactionType = type;
        this.quantity        = qty;
        this.pricePerShare   = price;
        this.totalAmount     = price.multiply(BigDecimal.valueOf(qty));
    }

    // ── Getters & Setters ─────────────────────────────────────────────────────
    public int        getId()                 { return id; }
    public void       setId(int id)           { this.id = id; }

    public int        getUserId()             { return userId; }
    public void       setUserId(int uid)      { this.userId = uid; }

    public int        getStockId()            { return stockId; }
    public void       setStockId(int sid)     { this.stockId = sid; }

    public String     getTransactionType()           { return transactionType; }
    public void       setTransactionType(String t)   { this.transactionType = t; }

    public int        getQuantity()           { return quantity; }
    public void       setQuantity(int q)      { this.quantity = q; }

    public BigDecimal getPricePerShare()               { return pricePerShare; }
    public void       setPricePerShare(BigDecimal p)   { this.pricePerShare = p; }

    public BigDecimal getTotalAmount()               { return totalAmount; }
    public void       setTotalAmount(BigDecimal t)   { this.totalAmount = t; }

    public Timestamp  getTransactionTime()              { return transactionTime; }
    public void       setTransactionTime(Timestamp t)   { this.transactionTime = t; }

    public String     getStockSymbol()                { return stockSymbol; }
    public void       setStockSymbol(String s)        { this.stockSymbol = s; }

    public String     getCompanyName()                { return companyName; }
    public void       setCompanyName(String n)        { this.companyName = n; }

    @Override
    public String toString() {
        return transactionType + " " + quantity + " x " + stockSymbol + " @ $" + pricePerShare;
    }
}
