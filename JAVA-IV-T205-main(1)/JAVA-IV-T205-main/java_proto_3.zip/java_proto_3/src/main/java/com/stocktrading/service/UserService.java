package com.stocktrading.service;

import com.stocktrading.dao.*;
import com.stocktrading.model.*;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

/**
 * UserService - Business logic for user authentication and account management.
 */
public class UserService {

    private final UserDAO userDAO = new UserDAO();

    /** Authenticates a user. Returns the User object or null on failure. */
    public User login(String username, String password) {
        try {
            return userDAO.login(username, password);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Registers a new user account.
     * @return null on success, or an error message string on failure.
     */
    public String register(String username, String password, String email) {
        if (username == null || username.trim().isEmpty()) return "Username cannot be empty.";
        if (password == null || password.length() < 4)    return "Password must be at least 4 characters.";
        if (email == null || !email.contains("@"))        return "Invalid email address.";

        try {
            if (userDAO.usernameExists(username)) return "Username already taken.";
            User u = new User(username.trim(), password, email.trim());
            boolean ok = userDAO.register(u);
            return ok ? null : "Registration failed. Email may already be in use.";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Database error: " + e.getMessage();
        }
    }

    /** Returns a fresh copy of the user from the database. */
    public User refreshUser(int userId) {
        try { return userDAO.findById(userId); } catch (SQLException e) { e.printStackTrace(); return null; }
    }

    /** Updates the user's cash balance. */
    public boolean updateBalance(int userId, BigDecimal newBalance) {
        try { return userDAO.updateBalance(userId, newBalance); } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    /** Returns top-10 users by balance for the leaderboard. */
    public List<User> getLeaderboard() {
        try { return userDAO.getLeaderboard(); } catch (SQLException e) { e.printStackTrace(); return List.of(); }
    }
}
