package com.stocktrading.dao;

import com.stocktrading.model.Transaction;
import com.stocktrading.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * TransactionDAO - Manages the `transactions` table.
 */
public class TransactionDAO {

    /**
     * Records a completed buy or sell transaction.
     */
    public boolean recordTransaction(Transaction tx) throws SQLException {
        String sql = "INSERT INTO transactions (user_id, stock_id, transaction_type, quantity, price_per_share, total_amount) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
            ps.setInt(1, tx.getUserId());
            ps.setInt(2, tx.getStockId());
            ps.setString(3, tx.getTransactionType());
            ps.setInt(4, tx.getQuantity());
            ps.setBigDecimal(5, tx.getPricePerShare());
            ps.setBigDecimal(6, tx.getTotalAmount());
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Returns all transactions for a user, most recent first, with stock symbol.
     */
    public List<Transaction> findByUser(int userId) throws SQLException {
        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT t.*, s.symbol, s.company_name " +
                     "FROM transactions t JOIN stocks s ON t.stock_id = s.id " +
                     "WHERE t.user_id = ? ORDER BY t.transaction_time DESC";
        try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    /**
     * Returns the last N transactions for quick display.
     */
    public List<Transaction> findRecentByUser(int userId, int limit) throws SQLException {
        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT t.*, s.symbol, s.company_name " +
                     "FROM transactions t JOIN stocks s ON t.stock_id = s.id " +
                     "WHERE t.user_id = ? ORDER BY t.transaction_time DESC LIMIT ?";
        try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, limit);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    // ── Mapping ───────────────────────────────────────────────────────────────
    private Transaction mapRow(ResultSet rs) throws SQLException {
        Transaction t = new Transaction();
        t.setId(rs.getInt("id"));
        t.setUserId(rs.getInt("user_id"));
        t.setStockId(rs.getInt("stock_id"));
        t.setTransactionType(rs.getString("transaction_type"));
        t.setQuantity(rs.getInt("quantity"));
        t.setPricePerShare(rs.getBigDecimal("price_per_share"));
        t.setTotalAmount(rs.getBigDecimal("total_amount"));
        t.setTransactionTime(rs.getTimestamp("transaction_time"));
        t.setStockSymbol(rs.getString("symbol"));
        t.setCompanyName(rs.getString("company_name"));
        return t;
    }
}
