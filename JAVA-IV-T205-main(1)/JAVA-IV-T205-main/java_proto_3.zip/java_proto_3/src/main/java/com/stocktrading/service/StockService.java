package com.stocktrading.service;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import com.stocktrading.dao.StockDAO;
import com.stocktrading.model.Stock;

/**
 * StockService - Business logic for stock management (admin + read operations).
 */
public class StockService {

    private final StockDAO stockDAO = new StockDAO();

    public List<Stock> getAllStocks() {
        try {
            return stockDAO.findAll();
        } catch (SQLException e) {
            e.printStackTrace();
            return List.of();
        }
    }

    public Stock getStockById(int id) {
        try {
            return stockDAO.findById(id);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public Stock getStockBySymbol(String symbol) {
        try {
            return stockDAO.findBySymbol(symbol);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Gets complete price history for a stock from the database.
     * Returns list of Object[] containing [Timestamp, double price].
     */
    public List<Object[]> getPriceHistory(int stockId) {
        try {
            return stockDAO.getPriceHistory(stockId);
        } catch (SQLException e) {
            System.err.println("Error fetching price history for stock ID " + stockId + ": " + e.getMessage());
            e.printStackTrace();
            return List.of();
        }
    }

    /** Admin: add a new stock. Returns null on success or error message. */
    public String addStock(String symbol, String companyName, String priceStr, String sector) {
        if (symbol == null || symbol.trim().isEmpty())
            return "Symbol cannot be empty.";
        if (companyName == null || companyName.isEmpty())
            return "Company name cannot be empty.";
        try {
            BigDecimal price = new BigDecimal(priceStr.trim());
            if (price.compareTo(BigDecimal.ZERO) <= 0)
                return "Price must be positive.";
            Stock s = new Stock(symbol.trim().toUpperCase(), companyName.trim(), price, sector);
            int id = stockDAO.addStock(s);
            return id > 0 ? null : "Failed to add stock.";
        } catch (NumberFormatException e) {
            return "Invalid price format.";
        } catch (SQLException e) {
            return e.getMessage().contains("Duplicate") ? "Stock symbol already exists." : e.getMessage();
        }
    }

    /** Admin: update an existing stock. */
    public String updateStock(int id, String symbol, String companyName, String priceStr, String sector) {
        try {
            BigDecimal price = new BigDecimal(priceStr.trim());
            Stock s = new Stock(symbol.trim().toUpperCase(), companyName.trim(), price, sector);
            s.setId(id);
            return stockDAO.updateStock(s) ? null : "Update failed.";
        } catch (NumberFormatException e) {
            return "Invalid price format.";
        } catch (SQLException e) {
            return e.getMessage();
        }
    }

    /** Admin: delete a stock. */
    public String deleteStock(int id) {
        try {
            return stockDAO.deleteStock(id) ? null : "Delete failed.";
        } catch (SQLException e) {
            return e.getMessage();
        }
    }

    /** Called by simulator to push a new simulated price. */
    public boolean updatePriceSimulated(int stockId, BigDecimal newPrice) {
        try {
            boolean ok = stockDAO.updatePrice(stockId, newPrice);
            if (ok)
                stockDAO.recordPriceHistory(stockId, newPrice);
            return ok;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Stock> getTopGainers(int n) {
        try {
            return stockDAO.getTopGainers(n);
        } catch (SQLException e) {
            e.printStackTrace();
            return List.of();
        }
    }

    public List<Stock> getTopLosers(int n) {
        try {
            return stockDAO.getTopLosers(n);
        } catch (SQLException e) {
            e.printStackTrace();
            return List.of();
        }
    }
}