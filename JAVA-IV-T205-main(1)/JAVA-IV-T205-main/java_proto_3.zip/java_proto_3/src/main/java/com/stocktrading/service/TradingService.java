package com.stocktrading.service;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.stocktrading.dao.PortfolioDAO;
import com.stocktrading.dao.StockDAO;
import com.stocktrading.dao.TransactionDAO;
import com.stocktrading.dao.UserDAO;
import com.stocktrading.model.Portfolio;
import com.stocktrading.model.Stock;
import com.stocktrading.model.Transaction;
import com.stocktrading.model.User;
import com.stocktrading.util.DatabaseConnection;

/**
 * TradingService - Orchestrates BUY and SELL operations. Coordinates UserDAO,
 * PortfolioDAO, and TransactionDAO in one atomic workflow.
 */
public class TradingService {

    private final UserDAO userDAO = new UserDAO();
    private final StockDAO stockDAO = new StockDAO();
    private final PortfolioDAO portfolioDAO = new PortfolioDAO();
    private final TransactionDAO transactionDAO = new TransactionDAO();

    /**
     * Executes a BUY order.
     *
     * @param userId  buyer's user ID
     * @param stockId stock to buy
     * @param qty     number of shares
     * @return null on success, or error message string
     */
    public synchronized String buy(int userId, int stockId, int qty) {
        if (qty <= 0) {
            return "Quantity must be at least 1.";
        }

        Connection conn = null;

        try {
            conn = DatabaseConnection.getInstance();
            conn.setAutoCommit(false); // 🔥 START TRANSACTION

            User user = userDAO.findById(userId);
            Stock stock = stockDAO.findById(stockId);

            if (user == null) {
                return "User not found.";
            }
            if (stock == null) {
                return "Invalid stock selected.";
            }

            BigDecimal price = stock.getCurrentPrice();
            BigDecimal totalCost = price.multiply(BigDecimal.valueOf(qty));

            if (user.getBalance().compareTo(totalCost) < 0) {
                return "Insufficient balance.";
            }

            // Update balance
            BigDecimal newBalance = user.getBalance().subtract(totalCost);
            if (!userDAO.updateBalance(userId, newBalance)) {
                conn.rollback();
                return "Balance update failed.";
            }

            // Update portfolio
            if (!portfolioDAO.addHolding(userId, stockId, qty, price)) {
                conn.rollback();
                return "Portfolio update failed.";
            }

            // Record transaction
            Transaction tx = new Transaction(userId, stockId, "BUY", qty, price);
            if (!transactionDAO.recordTransaction(tx)) {
                conn.rollback();
                return "Transaction record failed.";
            }

            // 🔥 TEST TRIGGER
            if (qty == 999) {
                throw new RuntimeException("test fail");
            }

            conn.commit();
            return null;

        } catch (Exception e) {
            try {
                if (conn != null) {
                    conn.rollback();

                }
            } catch (Exception ignored) {
            }
            return "Transaction failed.";

        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);

                }
            } catch (Exception ignored) {
            }
        }
    }

    /**
     * Executes a SELL order.
     *
     * @return null on success, or error message string
     */
    public synchronized String sell(int userId, int stockId, int qty) {
        if (qty <= 0) {
            return "Quantity must be at least 1.";
        }

        Connection conn = null;

        try {
            conn = DatabaseConnection.getInstance();
            conn.setAutoCommit(false); // 🔥 START TRANSACTION

            User user = userDAO.findById(userId);
            Stock stock = stockDAO.findById(stockId);
            Portfolio holding = portfolioDAO.findByUserAndStock(userId, stockId);

            if (user == null) {
                return "User not found.";
            }
            if (stock == null) {
                return "Invalid stock selected.";
            }
            if (holding == null || holding.getQuantity() < qty) {
                return "Not enough shares.";
            }

            BigDecimal proceeds = stock.getCurrentPrice().multiply(BigDecimal.valueOf(qty));

            // Update balance
            BigDecimal newBalance = user.getBalance().add(proceeds);
            if (!userDAO.updateBalance(userId, newBalance)) {
                conn.rollback();
                return "Balance update failed.";
            }

            // Update portfolio
            if (!portfolioDAO.removeHolding(userId, stockId, qty)) {
                conn.rollback();
                return "Portfolio update failed.";
            }

            // Record transaction
            Transaction tx = new Transaction(userId, stockId, "SELL", qty, stock.getCurrentPrice());
            if (!transactionDAO.recordTransaction(tx)) {
                conn.rollback();
                return "Transaction record failed.";
            }

            conn.commit(); // ✅ SUCCESS
            return null;

        } catch (Exception e) {
            try {
                if (conn != null) {
                    conn.rollback();

                }
            } catch (Exception ignored) {
            }
            return "Transaction failed.";

        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);

                }
            } catch (Exception ignored) {
            }
        }
    }

    // ── Portfolio & History ───────────────────────────────────────────────────
    public List<Portfolio> getPortfolio(int userId) {
        try {
            return portfolioDAO.findByUser(userId);
        } catch (SQLException e) {
            e.printStackTrace();
            return List.of();
        }
    }

    public BigDecimal getTotalPortfolioValue(int userId) {
        try {
            return portfolioDAO.getTotalPortfolioValue(userId);
        } catch (SQLException e) {
            e.printStackTrace();
            return BigDecimal.ZERO;
        }
    }

    public List<Transaction> getTransactionHistory(int userId) {
        try {
            return transactionDAO.findByUser(userId);
        } catch (SQLException e) {
            e.printStackTrace();
            return List.of();
        }
    }

    public List<Transaction> getRecentTransactions(int userId, int limit) {
        try {
            return transactionDAO.findRecentByUser(userId, limit);
        } catch (SQLException e) {
            e.printStackTrace();
            return List.of();
        }
    }

    public Portfolio getHolding(int userId, int stockId) {
        try {
            return portfolioDAO.findByUserAndStock(userId, stockId);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}