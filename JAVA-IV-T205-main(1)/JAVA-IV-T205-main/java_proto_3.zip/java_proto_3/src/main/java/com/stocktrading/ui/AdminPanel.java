package com.stocktrading.ui;

import com.stocktrading.model.Stock;
import com.stocktrading.service.StockService;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

/**
 * AdminPanel - Accessible only to users with ADMIN role.
 * Allows adding, editing, and deleting stocks.
 */
public class AdminPanel extends JPanel {

    private final StockService stockService;

    private JTable        table;
    private StockAdminModel tableModel;

    // Form fields
    private JTextField fSymbol, fName, fPrice, fSector;
    private JLabel     formError;
    private JButton    btnAdd, btnUpdate, btnDelete;

    private int selectedStockId = -1;

    public AdminPanel(StockService ss) {
        this.stockService = ss;
        setLayout(new BorderLayout(0, 0));
        setBackground(UITheme.BG_DARK);
        buildUI();
    }

    private void buildUI() {
        // ── Header ────────────────────────────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.BG_DARK);
        header.setBorder(BorderFactory.createEmptyBorder(20, 24, 12, 24));
        JLabel title = new JLabel("⚙️ Admin — Stock Management");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.GOLD);
        JButton refreshBtn = UITheme.primaryButton("↻ Refresh");
        refreshBtn.addActionListener(e -> refresh());
        header.add(title,      BorderLayout.WEST);
        header.add(refreshBtn, BorderLayout.EAST);

        // ── Main split: table left, form right ────────────────────────────────
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                buildTable(), buildForm());
        split.setDividerLocation(720);
        split.setBackground(UITheme.BG_DARK);
        split.setBorder(BorderFactory.createEmptyBorder());
        split.setDividerSize(4);

        add(header, BorderLayout.NORTH);
        add(split,  BorderLayout.CENTER);
    }

    // ── Stock Table ───────────────────────────────────────────────────────────

    private JPanel buildTable() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UITheme.BG_DARK);

        String[] cols = {"ID", "Symbol", "Company Name", "Current Price", "Prev Price", "Sector"};
        tableModel = new StockAdminModel(cols);
        table = new JTable(tableModel) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table.setRowHeight(34);
        table.setShowGrid(false);
        table.setBackground(UITheme.BG_CARD);
        table.setForeground(UITheme.TEXT_PRIMARY);
        table.setSelectionBackground(UITheme.BG_HOVER);
        table.setFont(UITheme.FONT_BODY);

        int[] widths = {50, 80, 260, 120, 120, 140};
        for (int i = 0; i < widths.length; i++)
            table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);

        table.getTableHeader().setBackground(UITheme.BG_PANEL);
        table.getTableHeader().setForeground(UITheme.GOLD);
        table.getTableHeader().setFont(UITheme.FONT_HEADING);
        table.getTableHeader().setPreferredSize(new Dimension(0, 36));
        table.getTableHeader().setReorderingAllowed(false);

        // Populate form when row is selected
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                Stock s = tableModel.getAt(table.getSelectedRow());
                loadIntoForm(s);
            }
        });

        table.setDefaultRenderer(Object.class, new AdminTableRenderer());

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(UITheme.BG_CARD);

        panel.add(scroll, BorderLayout.CENTER);
        return panel;
    }

    // ── Add / Edit Form ───────────────────────────────────────────────────────

    private JPanel buildForm() {
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(UITheme.BG_PANEL);
        form.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 1, 0, 0, UITheme.BORDER_COLOR),
            BorderFactory.createEmptyBorder(24, 24, 24, 24)));

        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.weightx = 1;
        g.gridx = 0;
        g.insets = new Insets(6, 0, 6, 0);

        JLabel formTitle = new JLabel("Add / Edit Stock");
        formTitle.setFont(UITheme.FONT_HEADING);
        formTitle.setForeground(UITheme.GOLD);
        g.gridy = 0; g.insets = new Insets(0, 0, 16, 0); form.add(formTitle, g);
        g.insets = new Insets(4, 0, 4, 0);

        fSymbol = UITheme.textField(15);
        fName   = UITheme.textField(15);
        fPrice  = UITheme.textField(15);
        fSector = UITheme.textField(15);

        g.gridy = 1; form.add(fieldLbl("Ticker Symbol (e.g. AAPL):"), g);
        g.gridy = 2; form.add(fSymbol, g);
        g.gridy = 3; form.add(fieldLbl("Company Name:"), g);
        g.gridy = 4; form.add(fName, g);
        g.gridy = 5; form.add(fieldLbl("Current Price ($):"), g);
        g.gridy = 6; form.add(fPrice, g);
        g.gridy = 7; form.add(fieldLbl("Sector:"), g);
        g.gridy = 8; form.add(fSector, g);

        formError = new JLabel(" ");
        formError.setFont(UITheme.FONT_SMALL);
        formError.setForeground(UITheme.RED_DOWN);
        g.gridy = 9; form.add(formError, g);

        // Buttons
        btnAdd    = UITheme.primaryButton("➕ Add New Stock");
        btnUpdate = UITheme.primaryButton("✏️ Update Selected");
        btnDelete = UITheme.dangerButton("🗑️ Delete Selected");

        btnAdd.addActionListener(e    -> doAdd());
        btnUpdate.addActionListener(e -> doUpdate());
        btnDelete.addActionListener(e -> doDelete());

        g.gridy = 10; g.insets = new Insets(14, 0, 6, 0); form.add(btnAdd,    g);
        g.gridy = 11; g.insets = new Insets(4, 0, 4, 0);   form.add(btnUpdate, g);
        g.gridy = 12;                                        form.add(btnDelete, g);

        JButton clearBtn = new JButton("Clear Form");
        clearBtn.setFont(UITheme.FONT_SMALL);
        clearBtn.setBackground(UITheme.BG_CARD);
        clearBtn.setForeground(UITheme.TEXT_SECONDARY);
        clearBtn.setBorderPainted(false);
        clearBtn.setFocusPainted(false);
        clearBtn.addActionListener(e -> clearForm());
        g.gridy = 13; g.insets = new Insets(8, 0, 0, 0); form.add(clearBtn, g);

        // Filler
        g.gridy = 14; g.weighty = 1; form.add(new JPanel() {{ setBackground(UITheme.BG_PANEL); }}, g);

        return form;
    }

    // ── CRUD Actions ──────────────────────────────────────────────────────────

    private void doAdd() {
        String err = stockService.addStock(
            fSymbol.getText(), fName.getText(), fPrice.getText(), fSector.getText());
        if (err != null) {
            showError(err);
        } else {
            showSuccess("Stock added successfully.");
            clearForm();
            refresh();
        }
    }

    private void doUpdate() {
        if (selectedStockId < 0) { showError("Select a stock from the table first."); return; }
        String err = stockService.updateStock(
            selectedStockId, fSymbol.getText(), fName.getText(), fPrice.getText(), fSector.getText());
        if (err != null) {
            showError(err);
        } else {
            showSuccess("Stock updated successfully.");
            refresh();
        }
    }

    private void doDelete() {
        if (selectedStockId < 0) { showError("Select a stock first."); return; }
        int confirm = JOptionPane.showConfirmDialog(this,
            "Delete this stock? This cannot be undone.", "Confirm Delete",
            JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm == JOptionPane.YES_OPTION) {
            String err = stockService.deleteStock(selectedStockId);
            if (err != null) {
                showError(err);
            } else {
                showSuccess("Stock deleted.");
                clearForm();
                refresh();
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void loadIntoForm(Stock s) {
        selectedStockId = s.getId();
        fSymbol.setText(s.getSymbol());
        fName.setText(s.getCompanyName());
        fPrice.setText(s.getCurrentPrice().toPlainString());
        fSector.setText(s.getSector() != null ? s.getSector() : "");
        formError.setText(" ");
    }

    private void clearForm() {
        selectedStockId = -1;
        fSymbol.setText(""); fName.setText(""); fPrice.setText(""); fSector.setText("");
        table.clearSelection();
        formError.setText(" ");
    }

    private void showError(String msg) {
        formError.setForeground(UITheme.RED_DOWN);
        formError.setText(msg);
    }

    private void showSuccess(String msg) {
        formError.setForeground(UITheme.GREEN_UP);
        formError.setText(msg);
    }

    private JLabel fieldLbl(String text) {
        JLabel l = UITheme.subLabel(text);
        return l;
    }

    public void refresh() {
        List<Stock> stocks = stockService.getAllStocks();
        tableModel.setStocks(stocks);
        tableModel.fireTableDataChanged();
    }

    // ── Table Model ───────────────────────────────────────────────────────────

    private static class StockAdminModel extends AbstractTableModel {
        private final String[] columns;
        private List<Stock> stocks = List.of();

        StockAdminModel(String[] cols) { this.columns = cols; }
        void setStocks(List<Stock> s)  { this.stocks = s; }

        @Override public int    getRowCount()    { return stocks.size(); }
        @Override public int    getColumnCount() { return columns.length; }
        @Override public String getColumnName(int c) { return columns[c]; }

        @Override
        public Object getValueAt(int row, int col) {
            Stock s = stocks.get(row);
            return switch (col) {
                case 0 -> s.getId();
                case 1 -> s.getSymbol();
                case 2 -> s.getCompanyName();
                case 3 -> String.format("$%.2f", s.getCurrentPrice());
                case 4 -> String.format("$%.2f", s.getPreviousPrice());
                case 5 -> s.getSector();
                default -> "";
            };
        }

        Stock getAt(int row) { return stocks.get(row); }
    }

    // ── Cell Renderer ─────────────────────────────────────────────────────────

    private class AdminTableRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int col) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
            setBackground(isSelected ? UITheme.BG_HOVER : (row % 2 == 0 ? UITheme.BG_CARD : UITheme.BG_PANEL));
            setForeground(UITheme.TEXT_PRIMARY);
            setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
            setFont(UITheme.FONT_BODY);
            if (col == 1) { setFont(UITheme.FONT_MONO_B); setForeground(UITheme.ACCENT_CYAN); }
            else if (col == 3) { setFont(UITheme.FONT_MONO_B); setForeground(UITheme.GREEN_UP); }
            return this;
        }
    }
}
