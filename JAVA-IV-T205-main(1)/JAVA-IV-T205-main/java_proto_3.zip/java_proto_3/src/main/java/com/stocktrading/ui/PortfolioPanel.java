package com.stocktrading.ui;

import com.stocktrading.model.*;
import com.stocktrading.service.*;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;

/**
 * PortfolioPanel - Displays the user's current stock holdings,
 * P&L per position, and summary statistics.
 */
public class PortfolioPanel extends JPanel {

    private User             user;
    private final TradingService tradingService;
    private final StockService   stockService;

    private JTable           table;
    private PortfolioModel   tableModel;

    // Summary labels
    private JLabel lblCash, lblPortfolioVal, lblTotalVal, lblTotalPnL;

    public PortfolioPanel(User user, TradingService ts, StockService ss) {
        this.user           = user;
        this.tradingService = ts;
        this.stockService   = ss;
        setLayout(new BorderLayout(0, 0));
        setBackground(UITheme.BG_DARK);
        buildUI();
    }

    public void setUser(User u) { this.user = u; }

    private void buildUI() {
        // ── Header ────────────────────────────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.BG_DARK);
        header.setBorder(BorderFactory.createEmptyBorder(20, 24, 12, 24));
        JLabel title = new JLabel("💼 My Portfolio");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_PRIMARY);
        JButton refreshBtn = UITheme.primaryButton("↻ Refresh");
        refreshBtn.addActionListener(e -> refresh());
        header.add(title,      BorderLayout.WEST);
        header.add(refreshBtn, BorderLayout.EAST);

        // ── Summary Cards ─────────────────────────────────────────────────────
        JPanel summaryRow = new JPanel(new GridLayout(1, 4, 12, 0));
        summaryRow.setBackground(UITheme.BG_DARK);
        summaryRow.setBorder(BorderFactory.createEmptyBorder(0, 24, 16, 24));

        lblCash         = statValue("$0.00");
        lblPortfolioVal = statValue("$0.00");
        lblTotalVal     = statValue("$0.00");
        lblTotalPnL     = statValue("$0.00");

        summaryRow.add(statCard("💵 Cash Balance",    lblCash));
        summaryRow.add(statCard("📦 Holdings Value",  lblPortfolioVal));
        summaryRow.add(statCard("💰 Net Worth",       lblTotalVal));
        summaryRow.add(statCard("📊 Total P&L",       lblTotalPnL));

        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(UITheme.BG_DARK);
        top.add(header,     BorderLayout.NORTH);
        top.add(summaryRow, BorderLayout.SOUTH);

        // ── Holdings Table ────────────────────────────────────────────────────
        String[] cols = {"Symbol", "Company", "Qty", "Avg Buy Price", "Current Price", "Invested", "Current Value", "P&L", "P&L %"};
        tableModel = new PortfolioModel(cols);
        table = new JTable(tableModel) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table.setRowHeight(36);
        table.setShowGrid(false);
        table.setBackground(UITheme.BG_CARD);
        table.setForeground(UITheme.TEXT_PRIMARY);
        table.setSelectionBackground(UITheme.BG_HOVER);
        table.setFont(UITheme.FONT_BODY);

        int[] widths = {80, 230, 60, 120, 120, 120, 120, 110, 90};
        for (int i = 0; i < widths.length; i++)
            table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);

        table.setDefaultRenderer(Object.class, new PortfolioRenderer());
        styleHeader(table.getTableHeader());

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UITheme.BORDER_COLOR));
        scroll.getViewport().setBackground(UITheme.BG_CARD);

        add(top,    BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(buildTransactionStrip(), BorderLayout.SOUTH);
    }

    // ── Recent Transactions strip ─────────────────────────────────────────────
    private JPanel transStrip;

    private JPanel buildTransactionStrip() {
        transStrip = new JPanel(new BorderLayout());
        transStrip.setBackground(UITheme.BG_PANEL);
        transStrip.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, UITheme.BORDER_COLOR),
            BorderFactory.createEmptyBorder(10, 24, 10, 24)));
        transStrip.setPreferredSize(new Dimension(0, 130));

        JLabel hdr = UITheme.heading("Recent Transactions");
        transStrip.add(hdr, BorderLayout.NORTH);
        return transStrip;
    }

    private void refreshTransactions(List<Transaction> txs) {
        transStrip.removeAll();
        transStrip.add(UITheme.heading("Recent Transactions"), BorderLayout.NORTH);

        String[] txCols = {"Time", "Type", "Symbol", "Qty", "Price", "Total"};
        Object[][] data = txs.stream().limit(5).map(tx -> new Object[]{
            tx.getTransactionTime().toString().substring(0, 16),
            tx.getTransactionType(),
            tx.getStockSymbol(),
            tx.getQuantity(),
            String.format("$%.2f", tx.getPricePerShare()),
            String.format("$%.2f", tx.getTotalAmount())
        }).toArray(Object[][]::new);

        JTable txTable = new JTable(data, txCols) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        txTable.setBackground(UITheme.BG_PANEL);
        txTable.setForeground(UITheme.TEXT_PRIMARY);
        txTable.setFont(UITheme.FONT_SMALL);
        txTable.setRowHeight(22);
        txTable.setShowGrid(false);
        txTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                comp.setBackground(UITheme.BG_PANEL);
                String val = v == null ? "" : v.toString();
                if (c == 1) {
                    comp.setForeground("BUY".equals(val) ? UITheme.GREEN_UP : UITheme.RED_DOWN);
                } else {
                    comp.setForeground(UITheme.TEXT_SECONDARY);
                }
                setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
                return comp;
            }
        });
        styleHeader(txTable.getTableHeader());
        txTable.getTableHeader().setFont(UITheme.FONT_SMALL);
        txTable.getTableHeader().setPreferredSize(new Dimension(0, 24));

        JScrollPane sp = new JScrollPane(txTable);
        sp.setBorder(BorderFactory.createEmptyBorder());
        sp.getViewport().setBackground(UITheme.BG_PANEL);
        transStrip.add(sp, BorderLayout.CENTER);
        transStrip.revalidate();
        transStrip.repaint();
    }

    // ── Refresh ───────────────────────────────────────────────────────────────

    public void refresh() {
        List<Portfolio> holdings = tradingService.getPortfolio(user.getId());
        tableModel.setHoldings(holdings);
        tableModel.fireTableDataChanged();

        // Recalculate summary
        User fresh = new com.stocktrading.service.UserService().refreshUser(user.getId());
        BigDecimal cash   = fresh != null ? fresh.getBalance() : user.getBalance();
        BigDecimal portVal = tradingService.getTotalPortfolioValue(user.getId());
        BigDecimal netWorth = cash.add(portVal);

        BigDecimal totalInvested = holdings.stream()
            .map(Portfolio::getInvestedValue)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalPnL = portVal.subtract(totalInvested);

        lblCash.setText("$" + String.format("%,.2f", cash));
        lblPortfolioVal.setText("$" + String.format("%,.2f", portVal));
        lblTotalVal.setText("$" + String.format("%,.2f", netWorth));
        lblTotalPnL.setText((totalPnL.signum() >= 0 ? "+" : "") + "$" + String.format("%,.2f", totalPnL));
        lblTotalPnL.setForeground(totalPnL.signum() >= 0 ? UITheme.GREEN_UP : UITheme.RED_DOWN);

        refreshTransactions(tradingService.getRecentTransactions(user.getId(), 5));
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private JPanel statCard(String title, JLabel valueLabel) {
        JPanel card = UITheme.card();
        card.setLayout(new BorderLayout(0, 6));
        JLabel t = UITheme.subLabel(title);
        card.add(t,          BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        return card;
    }

    private JLabel statValue(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(UITheme.FONT_MONO_B);
        lbl.setForeground(UITheme.TEXT_PRIMARY);
        return lbl;
    }

    private void styleHeader(JTableHeader th) {
        th.setBackground(UITheme.BG_PANEL);
        th.setForeground(UITheme.ACCENT_BLUE);
        th.setFont(UITheme.FONT_HEADING);
        th.setPreferredSize(new Dimension(0, 34));
        th.setReorderingAllowed(false);
    }

    // ── Table Model ───────────────────────────────────────────────────────────

    private static class PortfolioModel extends AbstractTableModel {
        private final String[] columns;
        private List<Portfolio> holdings = List.of();

        PortfolioModel(String[] cols) { this.columns = cols; }
        void setHoldings(List<Portfolio> h) { this.holdings = h; }

        @Override public int getRowCount()    { return holdings.size(); }
        @Override public int getColumnCount() { return columns.length; }
        @Override public String getColumnName(int c) { return columns[c]; }

        @Override
        public Object getValueAt(int row, int col) {
            Portfolio p = holdings.get(row);
            return switch (col) {
                case 0 -> p.getStockSymbol();
                case 1 -> p.getCompanyName();
                case 2 -> p.getQuantity();
                case 3 -> String.format("$%.2f", p.getAverageBuyPrice());
                case 4 -> String.format("$%.2f", p.getCurrentPrice());
                case 5 -> String.format("$%.2f", p.getInvestedValue());
                case 6 -> String.format("$%.2f", p.getCurrentValue());
                case 7 -> String.format("%+.2f", p.getProfitLoss());
                case 8 -> String.format("%+.2f%%", p.getProfitLossPercent());
                default -> "";
            };
        }

        Portfolio getAt(int row) { return holdings.get(row); }
    }

    // ── Cell Renderer ─────────────────────────────────────────────────────────

    private class PortfolioRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(
                JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int col) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);

            Portfolio p = tableModel.getAt(row);
            double pnlPct = p.getProfitLossPercent();

            setBackground(isSelected ? UITheme.BG_HOVER : (row % 2 == 0 ? UITheme.BG_CARD : UITheme.BG_PANEL));
            setForeground(UITheme.TEXT_PRIMARY);
            setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
            setFont(UITheme.FONT_BODY);

            if (col == 0) { setFont(UITheme.FONT_MONO_B); setForeground(UITheme.ACCENT_CYAN); }
            else if (col == 4) { setFont(UITheme.FONT_MONO_B); }
            else if (col == 7 || col == 8) {
                setFont(UITheme.FONT_MONO_B);
                setForeground(UITheme.changeColor(pnlPct));
            }
            return this;
        }
    }
}
