package com.stocktrading.model;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Portfolio - POJO representing a user's holding in a single stock.
 */
public class Portfolio {

    private int        id;
    private int        userId;
    private int        stockId;
    private int        quantity;
    private BigDecimal averageBuyPrice;

    // ── Display fields (joined from stocks table) ─────────────────────────────
    private String     stockSymbol;
    private String     companyName;
    private BigDecimal currentPrice;
    private String     sector;

    // ── Constructors ──────────────────────────────────────────────────────────
    public Portfolio() {}

    // ── Business Logic ────────────────────────────────────────────────────────

    /** Total amount invested in this position. */
    public BigDecimal getInvestedValue() {
        return averageBuyPrice.multiply(BigDecimal.valueOf(quantity));
    }

    /** Current market value of this position. */
    public BigDecimal getCurrentValue() {
        if (currentPrice == null) return BigDecimal.ZERO;
        return currentPrice.multiply(BigDecimal.valueOf(quantity));
    }

    /** Profit or Loss = currentValue - investedValue */
    public BigDecimal getProfitLoss() {
        return getCurrentValue().subtract(getInvestedValue());
    }

    /** Profit / Loss as a percentage of invested value. */
    public double getProfitLossPercent() {
        BigDecimal invested = getInvestedValue();
        if (invested.compareTo(BigDecimal.ZERO) == 0) return 0.0;
        return getProfitLoss()
                .divide(invested, 6, RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(100))
                .doubleValue();
    }

    // ── Getters & Setters ─────────────────────────────────────────────────────
    public int        getId()              { return id; }
    public void       setId(int id)        { this.id = id; }

    public int        getUserId()          { return userId; }
    public void       setUserId(int uid)   { this.userId = uid; }

    public int        getStockId()         { return stockId; }
    public void       setStockId(int sid)  { this.stockId = sid; }

    public int        getQuantity()        { return quantity; }
    public void       setQuantity(int q)   { this.quantity = q; }

    public BigDecimal getAverageBuyPrice()             { return averageBuyPrice; }
    public void       setAverageBuyPrice(BigDecimal p) { this.averageBuyPrice = p; }

    public String     getStockSymbol()             { return stockSymbol; }
    public void       setStockSymbol(String s)     { this.stockSymbol = s; }

    public String     getCompanyName()             { return companyName; }
    public void       setCompanyName(String n)     { this.companyName = n; }

    public BigDecimal getCurrentPrice()              { return currentPrice; }
    public void       setCurrentPrice(BigDecimal p)  { this.currentPrice = p; }

    public String     getSector()          { return sector; }
    public void       setSector(String s)  { this.sector = s; }
}
