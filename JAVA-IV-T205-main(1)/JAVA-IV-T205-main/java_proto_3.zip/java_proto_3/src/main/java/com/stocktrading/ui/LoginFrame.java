package com.stocktrading.ui;

import com.stocktrading.model.User;
import com.stocktrading.service.UserService;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

/**
 * LoginFrame - The first screen users see.
 * Provides Login and Register tabs with dark trading-terminal aesthetic.
 */
public class LoginFrame extends JFrame {

    private final UserService userService = new UserService();

    // ── Login fields ──────────────────────────────────────────────────────────
    private JTextField     loginUsername;
    private JPasswordField loginPassword;
    private JLabel         loginError;

    // ── Register fields ───────────────────────────────────────────────────────
    private JTextField     regUsername;
    private JPasswordField regPassword;
    private JTextField     regEmail;
    private JLabel         regError;

    public LoginFrame() {
        setTitle("Stock Trading Simulation System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(480, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(UITheme.BG_DARK);

        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(UITheme.BG_DARK);
        root.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        gbc.insets = new Insets(4, 0, 4, 0);

        // ── Logo / Header ─────────────────────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.BG_DARK);
        JLabel icon = new JLabel("📈", SwingConstants.CENTER);
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 48));
        JLabel title = new JLabel("StockSim Pro", SwingConstants.CENTER);
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ACCENT_BLUE);
        JLabel subtitle = new JLabel("Real-Time Stock Trading Simulator", SwingConstants.CENTER);
        subtitle.setFont(UITheme.FONT_SMALL);
        subtitle.setForeground(UITheme.TEXT_SECONDARY);
        header.add(icon,     BorderLayout.NORTH);
        header.add(title,    BorderLayout.CENTER);
        header.add(subtitle, BorderLayout.SOUTH);

        gbc.gridy = 0; gbc.insets = new Insets(0, 0, 20, 0);
        root.add(header, gbc);

        // ── Tab pane ──────────────────────────────────────────────────────────
        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(UITheme.BG_PANEL);
        tabs.setForeground(UITheme.TEXT_PRIMARY);
        tabs.setFont(UITheme.FONT_HEADING);
        tabs.add("  Login  ", buildLoginPanel());
        tabs.add("  Register  ", buildRegisterPanel());

        gbc.gridy = 1; gbc.insets = new Insets(0, 0, 0, 0);
        root.add(tabs, gbc);

        setContentPane(root);
    }

    // ── Login Panel ───────────────────────────────────────────────────────────

    private JPanel buildLoginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(UITheme.BG_PANEL);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.weightx = 1;
        g.insets = new Insets(6, 0, 6, 0);

        loginUsername = UITheme.textField(20);
        loginPassword = UITheme.passwordField(20);
        loginError    = new JLabel(" ");
        loginError.setForeground(UITheme.RED_DOWN);
        loginError.setFont(UITheme.FONT_SMALL);

        JButton loginBtn = UITheme.primaryButton("LOGIN");
        loginBtn.addActionListener(e -> doLogin());

        // Allow Enter key to submit
        loginPassword.addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) doLogin();
            }
        });

        int row = 0;
        g.gridy = row++; panel.add(fieldLabel("Username"), g);
        g.gridy = row++; panel.add(loginUsername, g);
        g.gridy = row++; panel.add(fieldLabel("Password"), g);
        g.gridy = row++; panel.add(loginPassword, g);
        g.gridy = row++; g.insets = new Insets(4, 0, 0, 0); panel.add(loginError, g);
        g.gridy = row++;  g.insets = new Insets(14, 0, 6, 0); panel.add(loginBtn, g);

        JLabel hint = UITheme.subLabel("Demo — user: demo / pass: demo123  |  Admin: admin / admin123");
        hint.setHorizontalAlignment(SwingConstants.CENTER);
        g.gridy = row; g.insets = new Insets(8, 0, 0, 0);
        panel.add(hint, g);

        return panel;
    }

    private void doLogin() {
        String user = loginUsername.getText().trim();
        String pass = new String(loginPassword.getPassword());

        if (user.isEmpty() || pass.isEmpty()) {
            loginError.setText("Please enter username and password.");
            return;
        }

        User loggedIn = userService.login(user, pass);
        if (loggedIn == null) {
            loginError.setText("Invalid username or password.");
        } else {
            loginError.setText(" ");
            openMainWindow(loggedIn);
        }
    }

    // ── Register Panel ────────────────────────────────────────────────────────

    private JPanel buildRegisterPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(UITheme.BG_PANEL);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.weightx = 1;
        g.insets = new Insets(6, 0, 6, 0);

        regUsername = UITheme.textField(20);
        regPassword = UITheme.passwordField(20);
        regEmail    = UITheme.textField(20);
        regError    = new JLabel(" ");
        regError.setForeground(UITheme.RED_DOWN);
        regError.setFont(UITheme.FONT_SMALL);

        JButton regBtn = UITheme.primaryButton("CREATE ACCOUNT");
        regBtn.addActionListener(e -> doRegister());

        int row = 0;
        g.gridy = row++; panel.add(fieldLabel("Username"), g);
        g.gridy = row++; panel.add(regUsername, g);
        g.gridy = row++; panel.add(fieldLabel("Email"), g);
        g.gridy = row++; panel.add(regEmail, g);
        g.gridy = row++; panel.add(fieldLabel("Password"), g);
        g.gridy = row++; panel.add(regPassword, g);
        g.gridy = row++; g.insets = new Insets(4, 0, 0, 0); panel.add(regError, g);
        g.gridy = row++; g.insets = new Insets(14, 0, 6, 0); panel.add(regBtn, g);

        JLabel hint = UITheme.subLabel("New accounts start with $100,000.00 virtual cash");
        hint.setHorizontalAlignment(SwingConstants.CENTER);
        g.gridy = row; g.insets = new Insets(8, 0, 0, 0);
        panel.add(hint, g);

        return panel;
    }

    private void doRegister() {
        String user = regUsername.getText().trim();
        String pass = new String(regPassword.getPassword());
        String mail = regEmail.getText().trim();

        String error = userService.register(user, pass, mail);
        if (error != null) {
            regError.setForeground(UITheme.RED_DOWN);
            regError.setText(error);
        } else {
            regError.setForeground(UITheme.GREEN_UP);
            regError.setText("Account created! You can now log in.");
            regUsername.setText("");
            regPassword.setText("");
            regEmail.setText("");
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private JLabel fieldLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(UITheme.FONT_SMALL);
        lbl.setForeground(UITheme.TEXT_SECONDARY);
        return lbl;
    }

    private void openMainWindow(User user) {
        SwingUtilities.invokeLater(() -> {
            MainFrame main = new MainFrame(user);
            main.setVisible(true);
            dispose();
        });
    }

    /** Application entry point (for standalone testing). */
    public static void main(String[] args) {
        UITheme.applyGlobalDefaults();
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
