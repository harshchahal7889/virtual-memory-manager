package com.stocktrading.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import com.stocktrading.model.Portfolio;
import com.stocktrading.model.Stock;
import com.stocktrading.model.User;
import com.stocktrading.service.StockService;
import com.stocktrading.service.TradingService;
import com.stocktrading.service.UserService;
import com.stocktrading.simulator.StockPriceSimulator;

/**
 * TradingPanel - Allows users to buy and sell stocks.
 * Shows a searchable stock list on the left and a trade form on the right.
 */
public class TradingPanel extends JPanel {

    private User user;
private StockService stockService;
private TradingService tradingService;
private Runnable onTradeComplete;
private AnalyticsPanel analyticsPanel;
private StockPriceSimulator simulator;

    // Left side – stock picker
    private JList<Stock> stockList;
    private DefaultListModel<Stock> listModel;
    private JTextField searchField;

    // Right side – trade form
    private JLabel selectedSymbol, selectedName, selectedPrice, holdingQty;
    private JTextField qtyField;
    private JLabel balanceLabel, costLabel, errorLabel;
    // Full stock data
    private List<Stock> allStocks;

    public TradingPanel(User user,
                    StockService stockService,
                    TradingService tradingService,
                    Runnable onTradeComplete,
                    AnalyticsPanel analyticsPanel,
                    StockPriceSimulator simulator) {

    this.user = user;
    this.stockService = stockService;
    this.tradingService = tradingService;
    this.onTradeComplete = onTradeComplete;
    this.analyticsPanel = analyticsPanel;
    this.simulator = simulator;

    buildUI();
        new javax.swing.Timer(3000, e -> refreshStocks()).start();
        simulator.addListener(stock -> {
            SwingUtilities.invokeLater(() -> {
                if (stockList.getSelectedValue() != null &&
                        stock.getId() == stockList.getSelectedValue().getId()) {

                    selectedPrice.setText("$" + stock.getCurrentPrice());
                }
            });
        });
    }

    public void setUser(User u) {
        this.user = u;
        refreshBalanceLabel();
    }

    private void buildUI() {
        // ── Header ────────────────────────────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.BG_DARK);
        header.setBorder(BorderFactory.createEmptyBorder(20, 24, 12, 24));
        JLabel title = new JLabel("🔄 Trade Stocks");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_PRIMARY);
        header.add(title, BorderLayout.WEST);

        // ── Main split ────────────────────────────────────────────────────────
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, buildStockPicker(), buildTradeForm());
        split.setDividerLocation(340);
        split.setBackground(UITheme.BG_DARK);
        split.setBorder(BorderFactory.createEmptyBorder());
        split.setDividerSize(4);

        add(header, BorderLayout.NORTH);
        add(split, BorderLayout.CENTER);
    }

    // ── Stock Picker (left) ───────────────────────────────────────────────────

    private JPanel buildStockPicker() {
        JPanel panel = new JPanel(new BorderLayout(0, 0));
        panel.setBackground(UITheme.BG_PANEL);
        panel.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, UITheme.BORDER_COLOR));

        // Search bar
        JPanel searchPanel = new JPanel(new BorderLayout(6, 0));
        searchPanel.setBackground(UITheme.BG_PANEL);
        searchPanel.setBorder(BorderFactory.createEmptyBorder(12, 12, 8, 12));
        searchField = UITheme.textField(15);
        searchField.setToolTipText("Search by symbol or company name");
        JLabel searchIcon = new JLabel("🔍");
        searchPanel.add(searchIcon, BorderLayout.WEST);
        searchPanel.add(searchField, BorderLayout.CENTER);
        searchField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                filterStocks();
            }

            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                filterStocks();
            }

            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                filterStocks();
            }
        });

        // List
        listModel = new DefaultListModel<>();
        stockList = new JList<>(listModel);
        stockList.setBackground(UITheme.BG_PANEL);
        stockList.setForeground(UITheme.TEXT_PRIMARY);
        stockList.setFont(UITheme.FONT_BODY);
        stockList.setSelectionBackground(UITheme.BG_HOVER);
        stockList.setFixedCellHeight(48);
        stockList.setCellRenderer(new StockListCellRenderer());
        stockList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting())
                onStockSelected(stockList.getSelectedValue());
        });

        JScrollPane scroll = new JScrollPane(stockList);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(UITheme.BG_PANEL);

        panel.add(searchPanel, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        return panel;
    }

    private void filterStocks() {
        String q = searchField.getText().trim().toLowerCase();
        listModel.clear();
        if (allStocks == null)
            return;
        allStocks.stream()
                .filter(s -> q.isEmpty()
                        || s.getSymbol().toLowerCase().contains(q)
                        || s.getCompanyName().toLowerCase().contains(q))
                .forEach(listModel::addElement);
    }

    // ── Trade Form (right) ────────────────────────────────────────────────────

    private JPanel buildTradeForm() {
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(UITheme.BG_DARK);
        form.setBorder(BorderFactory.createEmptyBorder(24, 32, 24, 32));

        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.weightx = 1;
        g.gridx = 0;
        g.insets = new Insets(6, 0, 6, 0);

        // Selected stock info card
        JPanel infoCard = UITheme.card();
        infoCard.setLayout(new GridLayout(4, 1, 0, 4));
        selectedSymbol = new JLabel("← Select a stock");
        selectedSymbol.setFont(UITheme.FONT_MONO_B);
        selectedSymbol.setForeground(UITheme.ACCENT_CYAN);
        selectedName = UITheme.subLabel(" ");
        selectedPrice = new JLabel(" ");
        selectedPrice.setFont(UITheme.FONT_MONO_B);
        selectedPrice.setForeground(UITheme.TEXT_PRIMARY);
        holdingQty = UITheme.subLabel(" ");
        infoCard.add(selectedSymbol);
        infoCard.add(selectedName);
        infoCard.add(selectedPrice);
        infoCard.add(holdingQty);

        g.gridy = 0;
        form.add(infoCard, g);

        // Balance
        JPanel balCard = UITheme.card();
        balCard.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
        JLabel balLbl = UITheme.subLabel("Available Cash: ");
        balanceLabel = new JLabel("$" + String.format("%,.2f", user.getBalance()));
        balanceLabel.setFont(UITheme.FONT_MONO_B);
        balanceLabel.setForeground(UITheme.GREEN_UP);
        balCard.add(balLbl);
        balCard.add(balanceLabel);
        g.gridy = 1;
        form.add(balCard, g);

        // Quantity input
        g.gridy = 2;
        form.add(UITheme.subLabel("Quantity:"), g);
        qtyField = UITheme.textField(10);
        qtyField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                updateCostLabel();
            }

            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                updateCostLabel();
            }

            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                updateCostLabel();
            }
        });
        g.gridy = 3;
        form.add(qtyField, g);

        // Estimated cost
        costLabel = UITheme.subLabel("Estimated Cost: —");
        g.gridy = 4;
        form.add(costLabel, g);

        // Error label
        errorLabel = new JLabel(" ");
        errorLabel.setFont(UITheme.FONT_SMALL);
        errorLabel.setForeground(UITheme.RED_DOWN);
        g.gridy = 5;
        form.add(errorLabel, g);

        // Buttons
        JPanel btnRow = new JPanel(new GridLayout(1, 2, 12, 0));
        btnRow.setBackground(UITheme.BG_DARK);
        JButton buyBtn = UITheme.buyButton("▲ BUY");
        JButton sellBtn = UITheme.sellButton("▼ SELL");
        buyBtn.addActionListener(e -> doTrade("BUY"));
        sellBtn.addActionListener(e -> doTrade("SELL"));
        btnRow.add(buyBtn);
        btnRow.add(sellBtn);
        g.gridy = 6;
        g.insets = new Insets(16, 0, 0, 0);
        form.add(btnRow, g);

        return form;
    }

    private void onStockSelected(Stock stock) {
        if (stock == null)
            return;
        errorLabel.setText(" ");
        double pct = stock.getPercentageChange();
        selectedSymbol.setText(stock.getSymbol());
        selectedName.setText(stock.getCompanyName());
        selectedPrice.setText("$" + String.format("%.2f", stock.getCurrentPrice())
                + "  " + UITheme.changeArrow(pct)
                + String.format(" %+.2f%%", pct));
        selectedPrice.setForeground(UITheme.changeColor(pct));

        Portfolio holding = tradingService.getHolding(user.getId(), stock.getId());
        holdingQty.setText("You own: " + (holding == null ? 0 : holding.getQuantity()) + " shares");
        updateCostLabel();
        // 🔥 Update graph when stock is selected
        if (analyticsPanel != null) {
            analyticsPanel.setSelectedStock(stock);
        }
    }

    private void updateCostLabel() {
        Stock stock = stockList.getSelectedValue();
        if (stock == null) {
            costLabel.setText("Estimated Cost: —");
            return;
        }
        try {
            int qty = Integer.parseInt(qtyField.getText().trim());
            if (qty > 0) {
                double cost = stock.getCurrentPrice().doubleValue() * qty;
                costLabel.setText(String.format("Estimated Cost: $%,.2f", cost));
            }
        } catch (NumberFormatException ignored) {
            costLabel.setText("Estimated Cost: —");
        }
    }

    private void doTrade(String type) {
        Stock stock = stockList.getSelectedValue();
        if (stock == null) {
            errorLabel.setText("Please select a stock first.");
            return;
        }
        int qty;
        try {
            qty = Integer.parseInt(qtyField.getText().trim());
            if (qty <= 0)
                throw new NumberFormatException();
        } catch (NumberFormatException e) {
            errorLabel.setText("Enter a valid quantity (positive integer).");
            return;
        }

        String err = "BUY".equals(type)
                ? tradingService.buy(user.getId(), stock.getId(), qty)
                : tradingService.sell(user.getId(), stock.getId(), qty);

        if (err != null) {
            errorLabel.setText(err);
        } else {
            errorLabel.setText(" ");
            qtyField.setText("");
            JOptionPane.showMessageDialog(this,
                    type + " order executed: " + qty + " x " + stock.getSymbol()
                            + " @ $" + String.format("%.2f", stock.getCurrentPrice()),
                    "Trade Executed ✅", JOptionPane.INFORMATION_MESSAGE);
            onTradeComplete.run();
            refreshStocks();
            onStockSelected(stockList.getSelectedValue());
        }
    }

    // ── Public refresh ────────────────────────────────────────────────────────

    public void refreshStocks() {
        allStocks = stockService.getAllStocks();
        filterStocks();
        refreshBalanceLabel();

        // 🔥 ADD THIS BLOCK
        Stock selected = stockList.getSelectedValue();
        if (selected != null) {
            // find updated version of same stock
            for (Stock s : allStocks) {
                if (s.getId() == selected.getId()) {
                    onStockSelected(s);
                    break;
                }
            }
        }
    }

    private void refreshBalanceLabel() {
        User fresh = new UserService().refreshUser(user.getId());
        if (fresh != null) {
            user = fresh;
            balanceLabel.setText("$" + String.format("%,.2f", user.getBalance()));
        }
    }

    // ── Custom cell renderer for stock list ───────────────────────────────────

    private static class StockListCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value,
                int index, boolean isSelected, boolean hasFocus) {
            JPanel cell = new JPanel(new BorderLayout(0, 2));
            cell.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, UITheme.BORDER_COLOR),
                    BorderFactory.createEmptyBorder(6, 12, 6, 12)));
            cell.setBackground(isSelected ? UITheme.BG_HOVER : UITheme.BG_PANEL);

            Stock s = (Stock) value;
            double pct = s.getPercentageChange();

            JLabel sym = new JLabel(s.getSymbol());
            sym.setFont(UITheme.FONT_MONO_B);
            sym.setForeground(UITheme.ACCENT_CYAN);

            JLabel price = new JLabel(String.format("$%.2f", s.getCurrentPrice()));
            price.setFont(UITheme.FONT_MONO_B);
            price.setForeground(UITheme.TEXT_PRIMARY);

            JLabel name = UITheme.subLabel(s.getCompanyName());

            JLabel pctLbl = new JLabel(UITheme.changeArrow(pct) + String.format(" %.2f%%", pct));
            pctLbl.setFont(UITheme.FONT_SMALL);
            pctLbl.setForeground(UITheme.changeColor(pct));

            JPanel right = new JPanel(new GridLayout(2, 1));
            right.setBackground(cell.getBackground());
            right.add(price);
            right.add(pctLbl);

            cell.add(sym, BorderLayout.WEST);
            cell.add(name, BorderLayout.CENTER);
            cell.add(right, BorderLayout.EAST);
            return cell;
        }
    }
}
