package com.stocktrading.dao;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.stocktrading.model.Portfolio;
import com.stocktrading.util.DatabaseConnection;

/**
 * PortfolioDAO - Manages user stock holdings in the `portfolio` table.
 */
public class PortfolioDAO {

    /**
     * Returns all holdings for a user, joined with current stock prices.
     */
    public List<Portfolio> findByUser(int userId) throws SQLException {
        List<Portfolio> list = new ArrayList<>();
        String sql = "SELECT p.*, s.symbol, s.company_name, s.current_price, s.sector "
                + "FROM portfolio p JOIN stocks s ON p.stock_id = s.id "
                + "WHERE p.user_id = ? AND p.quantity > 0 ORDER BY s.symbol";
        try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    /**
     * Returns a specific holding, or null if not found.
     */
    public Portfolio findByUserAndStock(int userId, int stockId) throws SQLException {
        String sql = "SELECT p.*, s.symbol, s.company_name, s.current_price, s.sector "
                + "FROM portfolio p JOIN stocks s ON p.stock_id = s.id "
                + "WHERE p.user_id = ? AND p.stock_id = ?";
        try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, stockId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return mapRow(rs);
            }
        }
        return null;
    }

    /**
     * Adds shares to an existing portfolio entry (or creates one). Recalculates
     * the weighted-average buy price.
     */
    public boolean addHolding(int userId, int stockId, int qty, BigDecimal pricePerShare) throws SQLException {
        Portfolio existing = findByUserAndStock(userId, stockId);
        if (existing == null) {
            // New position
            String sql = "INSERT INTO portfolio (user_id, stock_id, quantity, average_buy_price) VALUES (?, ?, ?, ?)";
            try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
                ps.setInt(1, userId);
                ps.setInt(2, stockId);
                ps.setInt(3, qty);
                ps.setBigDecimal(4, pricePerShare);
                return ps.executeUpdate() > 0;
            }
        } else {
            // Existing position – compute weighted average
            int totalQty = existing.getQuantity() + qty;
            BigDecimal newAvg = existing.getAverageBuyPrice()
                    .multiply(BigDecimal.valueOf(existing.getQuantity()))
                    .add(pricePerShare.multiply(BigDecimal.valueOf(qty)))
                    .divide(BigDecimal.valueOf(totalQty), 4, RoundingMode.HALF_UP);

            String sql = "UPDATE portfolio SET quantity = ?, average_buy_price = ? WHERE user_id = ? AND stock_id = ?";
            try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
                ps.setInt(1, totalQty);
                ps.setBigDecimal(2, newAvg);
                ps.setInt(3, userId);
                ps.setInt(4, stockId);
                return ps.executeUpdate() > 0;
            }
        }
    }

    /**
     * Removes shares from an existing holding (sell operation). Returns false
     * if the user doesn't hold enough shares.
     */
    public boolean removeHolding(int userId, int stockId, int qty) throws SQLException {
        Portfolio existing = findByUserAndStock(userId, stockId);
        if (existing == null || existing.getQuantity() < qty) {
            return false;
        }

        int newQty = existing.getQuantity() - qty;

        if (newQty == 0) {
            String deleteSql = "DELETE FROM portfolio WHERE user_id = ? AND stock_id = ?";
            try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(deleteSql)) {
                ps.setInt(1, userId);
                ps.setInt(2, stockId);
                return ps.executeUpdate() > 0;
            }
        } else {
            String updateSql = "UPDATE portfolio SET quantity = ? WHERE user_id = ? AND stock_id = ?";
            try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(updateSql)) {
                ps.setInt(1, newQty);
                ps.setInt(2, userId);
                ps.setInt(3, stockId);
                return ps.executeUpdate() > 0;
            }
        }
    }

    /**
     * Returns the total current market value of all of a user's holdings.
     */
    public BigDecimal getTotalPortfolioValue(int userId) throws SQLException {
        String sql = "SELECT SUM(p.quantity * s.current_price) AS total "
                + "FROM portfolio p JOIN stocks s ON p.stock_id = s.id WHERE p.user_id = ?";
        try (PreparedStatement ps = DatabaseConnection.getInstance().prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next() && rs.getBigDecimal("total") != null) {
                return rs.getBigDecimal("total");
            }
        }
        return BigDecimal.ZERO;
    }

    // ── Mapping ───────────────────────────────────────────────────────────────
    private Portfolio mapRow(ResultSet rs) throws SQLException {
        Portfolio p = new Portfolio();
        p.setId(rs.getInt("id"));
        p.setUserId(rs.getInt("user_id"));
        p.setStockId(rs.getInt("stock_id"));
        p.setQuantity(rs.getInt("quantity"));
        p.setAverageBuyPrice(rs.getBigDecimal("average_buy_price"));
        p.setStockSymbol(rs.getString("symbol"));
        p.setCompanyName(rs.getString("company_name"));
        p.setCurrentPrice(rs.getBigDecimal("current_price"));
        p.setSector(rs.getString("sector"));
        return p;
    }
}
