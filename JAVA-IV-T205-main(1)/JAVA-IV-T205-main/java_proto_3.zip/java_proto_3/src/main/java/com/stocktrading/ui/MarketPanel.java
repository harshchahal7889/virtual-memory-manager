package com.stocktrading.ui;

import com.stocktrading.model.*;
import com.stocktrading.service.*;
import com.stocktrading.simulator.StockPriceSimulator;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

/**
 * MarketPanel - Shows all stocks with live price updates.
 * Rows flash green/red when prices change.
 */
public class MarketPanel extends JPanel {

    private User            user;
    private final StockService   stockService;
    private final TradingService tradingService;

    private JTable     table;
    private StockTableModel tableModel;
    private JLabel     statusLabel;

    // Column indices
    private static final int COL_SYMBOL  = 0;
    private static final int COL_NAME    = 1;
    private static final int COL_PRICE   = 2;
    private static final int COL_CHANGE  = 3;
    private static final int COL_PCT     = 4;
    private static final int COL_SECTOR  = 5;

    public MarketPanel(User user, StockService ss, TradingService ts, StockPriceSimulator sim) {
        this.user           = user;
        this.stockService   = ss;
        this.tradingService = ts;
        setLayout(new BorderLayout(0, 0));
        setBackground(UITheme.BG_DARK);
        buildUI();
        refresh();
    }

    private void buildUI() {
        // ── Header ────────────────────────────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.BG_DARK);
        header.setBorder(BorderFactory.createEmptyBorder(20, 24, 12, 24));

        JLabel title = new JLabel("📊 Live Market");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_PRIMARY);
        statusLabel = UITheme.subLabel("● LIVE — prices update every 2-4 seconds");
        statusLabel.setForeground(UITheme.GREEN_UP);

        JButton refreshBtn = UITheme.primaryButton("↻ Refresh");
        refreshBtn.addActionListener(e -> refresh());

        header.add(title,      BorderLayout.WEST);
        header.add(statusLabel,BorderLayout.CENTER);
        header.add(refreshBtn, BorderLayout.EAST);

        // ── Table ─────────────────────────────────────────────────────────────
        String[] cols = {"Symbol", "Company", "Price", "Change", "% Change", "Sector"};
        tableModel = new StockTableModel(cols);
        table = new JTable(tableModel) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        table.setRowHeight(36);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setBackground(UITheme.BG_CARD);
        table.setForeground(UITheme.TEXT_PRIMARY);
        table.setSelectionBackground(UITheme.BG_HOVER);
        table.setFont(UITheme.FONT_BODY);

        // Custom column widths
        table.getColumnModel().getColumn(COL_SYMBOL).setPreferredWidth(80);
        table.getColumnModel().getColumn(COL_NAME).setPreferredWidth(260);
        table.getColumnModel().getColumn(COL_PRICE).setPreferredWidth(110);
        table.getColumnModel().getColumn(COL_CHANGE).setPreferredWidth(100);
        table.getColumnModel().getColumn(COL_PCT).setPreferredWidth(100);
        table.getColumnModel().getColumn(COL_SECTOR).setPreferredWidth(150);

        table.setDefaultRenderer(Object.class, new StockTableRenderer());

        // Header styling
        JTableHeader th = table.getTableHeader();
        th.setBackground(UITheme.BG_PANEL);
        th.setForeground(UITheme.ACCENT_BLUE);
        th.setFont(UITheme.FONT_HEADING);
        th.setPreferredSize(new Dimension(0, 38));
        th.setReorderingAllowed(false);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UITheme.BORDER_COLOR));
        scroll.getViewport().setBackground(UITheme.BG_CARD);

        add(header, BorderLayout.NORTH);
        add(scroll,  BorderLayout.CENTER);
    }

    /** Reloads all stocks from the database. */
    public void refresh() {
        List<Stock> stocks = stockService.getAllStocks();
        tableModel.setStocks(stocks);
        tableModel.fireTableDataChanged();
    }

    /**
     * Called by the simulator listener for each updated stock.
     * Only updates the affected row to avoid full table refresh.
     */
    public void onPriceUpdate(Stock updatedStock) {
        tableModel.updateStock(updatedStock);
    }

    // ── Table Model ───────────────────────────────────────────────────────────

    private static class StockTableModel extends AbstractTableModel {
        private final String[] columns;
        private List<Stock>    stocks = List.of();

        StockTableModel(String[] cols) { this.columns = cols; }

        void setStocks(List<Stock> s)  { this.stocks = s; }

        void updateStock(Stock updated) {
            for (int i = 0; i < stocks.size(); i++) {
                if (stocks.get(i).getId() == updated.getId()) {
                    stocks.set(i, updated);
                    fireTableRowsUpdated(i, i);
                    return;
                }
            }
        }

        @Override public int    getRowCount()    { return stocks.size(); }
        @Override public int    getColumnCount() { return columns.length; }
        @Override public String getColumnName(int c) { return columns[c]; }

        @Override
        public Object getValueAt(int row, int col) {
            Stock s = stocks.get(row);
            double pct = s.getPercentageChange();
            return switch (col) {
                case COL_SYMBOL -> s.getSymbol();
                case COL_NAME   -> s.getCompanyName();
                case COL_PRICE  -> String.format("$%.2f", s.getCurrentPrice());
                case COL_CHANGE -> String.format("%+.2f", s.getCurrentPrice().subtract(s.getPreviousPrice()).doubleValue());
                case COL_PCT    -> String.format("%+.2f%%", pct);
                case COL_SECTOR -> s.getSector();
                default         -> "";
            };
        }

        Stock getStockAt(int row) { return stocks.get(row); }
    }

    // ── Cell Renderer ─────────────────────────────────────────────────────────

    private class StockTableRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(
                JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int col) {

            Component c = super.getTableCellRendererComponent(
                    table, value, isSelected, hasFocus, row, col);

            Stock s   = tableModel.getStockAt(row);
            double pct = s.getPercentageChange();

            c.setBackground(isSelected ? UITheme.BG_HOVER : (row % 2 == 0 ? UITheme.BG_CARD : UITheme.BG_PANEL));
            c.setForeground(UITheme.TEXT_PRIMARY);
            setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
            setFont(UITheme.FONT_BODY);

            // Color code price columns
            if (col == COL_SYMBOL) {
                setFont(UITheme.FONT_MONO_B);
                setForeground(UITheme.ACCENT_CYAN);
            } else if (col == COL_PRICE) {
                setFont(UITheme.FONT_MONO_B);
                setForeground(UITheme.TEXT_PRIMARY);
            } else if (col == COL_CHANGE || col == COL_PCT) {
                setForeground(UITheme.changeColor(pct));
                setFont(UITheme.FONT_MONO_B);
                setText(UITheme.changeArrow(pct) + " " + value);
            }
            return c;
        }
    }
}
