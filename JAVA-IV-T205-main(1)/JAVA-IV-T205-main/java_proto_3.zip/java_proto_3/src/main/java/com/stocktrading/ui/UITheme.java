package com.stocktrading.ui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

/**
 * UITheme - Central design system for the Stock Trading UI.
 * Dark, professional trading terminal aesthetic.
 */
public class UITheme {

    // ── Color Palette ─────────────────────────────────────────────────────────
    public static final Color BG_DARKEST   = new Color(10,  14,  26);   // near-black navy
    public static final Color BG_DARK      = new Color(16,  22,  40);   // main background
    public static final Color BG_PANEL     = new Color(22,  30,  52);   // panel background
    public static final Color BG_CARD      = new Color(28,  38,  65);   // card / row bg
    public static final Color BG_HOVER     = new Color(36,  50,  85);   // hover state

    public static final Color ACCENT_BLUE  = new Color(56, 139, 253);   // primary accent
    public static final Color ACCENT_CYAN  = new Color(22, 198, 204);   // secondary accent

    public static final Color GREEN_UP     = new Color(52, 211, 153);   // price up / profit
    public static final Color RED_DOWN     = new Color(248, 81,  73);   // price down / loss
    public static final Color GOLD         = new Color(255, 200, 87);   // admin / highlight

    public static final Color TEXT_PRIMARY  = new Color(226, 232, 255);
    public static final Color TEXT_SECONDARY= new Color(130, 145, 185);
    public static final Color TEXT_MUTED    = new Color(72,  85, 120);
    public static final Color BORDER_COLOR  = new Color(40,  55,  90);

    // ── Fonts ─────────────────────────────────────────────────────────────────
    public static final Font FONT_TITLE   = new Font("Segoe UI", Font.BOLD,  22);
    public static final Font FONT_HEADING = new Font("Segoe UI", Font.BOLD,  15);
    public static final Font FONT_BODY    = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_SMALL   = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font FONT_MONO    = new Font("JetBrains Mono", Font.PLAIN, 12);
    public static final Font FONT_MONO_B  = new Font("JetBrains Mono", Font.BOLD,  13);

    // ── Global LAF Setup ──────────────────────────────────────────────────────
    public static void applyGlobalDefaults() {
        UIManager.put("Panel.background",           BG_DARK);
        UIManager.put("Table.background",           BG_CARD);
        UIManager.put("Table.foreground",           TEXT_PRIMARY);
        UIManager.put("Table.gridColor",            BORDER_COLOR);
        UIManager.put("Table.selectionBackground",  BG_HOVER);
        UIManager.put("Table.selectionForeground",  TEXT_PRIMARY);
        UIManager.put("TableHeader.background",     BG_PANEL);
        UIManager.put("TableHeader.foreground",     ACCENT_BLUE);
        UIManager.put("TableHeader.font",           FONT_HEADING);
        UIManager.put("ScrollPane.background",      BG_DARK);
        UIManager.put("Viewport.background",        BG_DARK);
        UIManager.put("ScrollBar.background",       BG_PANEL);
        UIManager.put("ScrollBar.thumb",            BG_HOVER);
        UIManager.put("ScrollBar.track",            BG_DARK);
        UIManager.put("OptionPane.background",      BG_PANEL);
        UIManager.put("OptionPane.messageForeground", TEXT_PRIMARY);
        UIManager.put("Button.font",                FONT_BODY);
        UIManager.put("Label.font",                 FONT_BODY);
        UIManager.put("TextField.font",             FONT_BODY);
        UIManager.put("ComboBox.font",              FONT_BODY);
    }

    // ── Component Factories ───────────────────────────────────────────────────

    /** Creates a styled primary action button (blue). */
    public static JButton primaryButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_HEADING);
        btn.setBackground(ACCENT_BLUE);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        return btn;
    }

    /** Creates a styled buy button (green). */
    public static JButton buyButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_HEADING);
        btn.setBackground(GREEN_UP);
        btn.setForeground(new Color(10, 30, 20));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 28, 10, 28));
        return btn;
    }

    /** Creates a styled sell button (red). */
    public static JButton sellButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_HEADING);
        btn.setBackground(RED_DOWN);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 28, 10, 28));
        return btn;
    }

    /** Creates a styled danger/admin button (red outline). */
    public static JButton dangerButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BODY);
        btn.setBackground(new Color(80, 20, 20));
        btn.setForeground(RED_DOWN);
        btn.setFocusPainted(false);
        btn.setBorderPainted(true);
        btn.setBorder(BorderFactory.createLineBorder(RED_DOWN));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    /** Creates a dark-styled text field. */
    public static JTextField textField(int cols) {
        JTextField tf = new JTextField(cols);
        tf.setBackground(BG_DARKEST);
        tf.setForeground(TEXT_PRIMARY);
        tf.setCaretColor(ACCENT_BLUE);
        tf.setFont(FONT_BODY);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        return tf;
    }

    /** Creates a dark-styled password field. */
    public static JPasswordField passwordField(int cols) {
        JPasswordField pf = new JPasswordField(cols);
        pf.setBackground(BG_DARKEST);
        pf.setForeground(TEXT_PRIMARY);
        pf.setCaretColor(ACCENT_BLUE);
        pf.setFont(FONT_BODY);
        pf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        return pf;
    }

    /** Creates a section label (heading). */
    public static JLabel heading(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(FONT_HEADING);
        lbl.setForeground(TEXT_PRIMARY);
        return lbl;
    }

    /** Creates a muted secondary label. */
    public static JLabel subLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(FONT_SMALL);
        lbl.setForeground(TEXT_SECONDARY);
        return lbl;
    }

    /** Creates a card-styled JPanel with a rounded border. */
    public static JPanel card() {
        JPanel panel = new JPanel();
        panel.setBackground(BG_CARD);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR),
            BorderFactory.createEmptyBorder(16, 16, 16, 16)
        ));
        return panel;
    }

    /** Creates a separator styled for the dark theme. */
    public static JSeparator separator() {
        JSeparator sep = new JSeparator();
        sep.setForeground(BORDER_COLOR);
        sep.setBackground(BORDER_COLOR);
        return sep;
    }

    /** Formats a price change as "+1.23%" or "-0.45%" with color. */
    public static Color changeColor(double pct) {
        return pct >= 0 ? GREEN_UP : RED_DOWN;
    }

    /** Returns "▲" or "▼" indicator. */
    public static String changeArrow(double pct) {
        return pct >= 0 ? "▲" : "▼";
    }
}
