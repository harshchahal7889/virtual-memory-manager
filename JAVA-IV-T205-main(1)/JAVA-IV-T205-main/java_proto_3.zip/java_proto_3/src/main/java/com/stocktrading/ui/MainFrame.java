package com.stocktrading.ui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import com.stocktrading.model.User;
import com.stocktrading.service.StockService;
import com.stocktrading.service.TradingService;
import com.stocktrading.service.UserService;
import com.stocktrading.simulator.StockPriceSimulator;

/**
 * MainFrame - The main application window shown after login.
 * Hosts a sidebar for navigation and a card-based content area.
 */
public class MainFrame extends JFrame {

    private User user;
    private final UserService userService = new UserService();
    private final StockService stockService = new StockService();
    private final TradingService tradingService = new TradingService();
    private final StockPriceSimulator simulator;

    // ── Content panels ────────────────────────────────────────────────────────
    private MarketPanel marketPanel;
    private PortfolioPanel portfolioPanel;
    private TradingPanel tradingPanel;
    private AnalyticsPanel analyticsPanel;
    private AdminPanel adminPanel;

    private JPanel contentArea;
    private CardLayout cardLayout;

    // ── Header labels ─────────────────────────────────────────────────────────
    private JLabel balanceLabel;
    private JLabel userLabel;

    public MainFrame(User user) {
        this.user = user;
        this.simulator = new StockPriceSimulator(stockService);

        setTitle("StockSim Pro — " + user.getUsername());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 840);
        setMinimumSize(new Dimension(1100, 680));
        setLocationRelativeTo(null);

        buildUI();
        initSimulator();

        // Show market panel on startup
        showPanel("MARKET");
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.BG_DARKEST);

        root.add(buildTopBar(), BorderLayout.NORTH);
        root.add(buildSidebar(), BorderLayout.WEST);

        // Card layout for content
        cardLayout = new CardLayout();
        contentArea = new JPanel(cardLayout);
        contentArea.setBackground(UITheme.BG_DARK);

        marketPanel = new MarketPanel(user, stockService, tradingService, simulator);
        portfolioPanel = new PortfolioPanel(user, tradingService, stockService);
        analyticsPanel = new AnalyticsPanel(stockService, simulator);
        tradingPanel = new TradingPanel(user, stockService, tradingService, this::refreshUser, analyticsPanel, simulator);

        contentArea.add(marketPanel, "MARKET");
        contentArea.add(portfolioPanel, "PORTFOLIO");
        contentArea.add(tradingPanel, "TRADE");
        contentArea.add(analyticsPanel, "ANALYTICS");

        if (user.isAdmin()) {
            adminPanel = new AdminPanel(stockService);
            contentArea.add(adminPanel, "ADMIN");
        }

        root.add(contentArea, BorderLayout.CENTER);
        setContentPane(root);
    }

    // ── Top Bar ───────────────────────────────────────────────────────────────

    private JPanel buildTopBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(UITheme.BG_DARKEST);
        bar.setPreferredSize(new Dimension(0, 52));
        bar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, UITheme.BORDER_COLOR));

        // Left: logo
        JLabel logo = new JLabel("  📈  StockSim Pro");
        logo.setFont(UITheme.FONT_HEADING);
        logo.setForeground(UITheme.ACCENT_BLUE);
        bar.add(logo, BorderLayout.WEST);

        // Right: user info + balance + logout
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 16, 10));
        right.setBackground(UITheme.BG_DARKEST);

        userLabel = new JLabel(
                (user.isAdmin() ? "👑 " : "👤 ") + user.getUsername());
        userLabel.setFont(UITheme.FONT_BODY);
        userLabel.setForeground(user.isAdmin() ? UITheme.GOLD : UITheme.TEXT_PRIMARY);

        balanceLabel = new JLabel("💰 $" + String.format("%,.2f", user.getBalance()));
        balanceLabel.setFont(UITheme.FONT_MONO_B);
        balanceLabel.setForeground(UITheme.GREEN_UP);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setFont(UITheme.FONT_SMALL);
        logoutBtn.setBackground(new Color(50, 30, 30));
        logoutBtn.setForeground(UITheme.RED_DOWN);
        logoutBtn.setBorderPainted(false);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        logoutBtn.addActionListener(e -> doLogout());

        right.add(userLabel);
        right.add(new JLabel("|") {
            {
                setForeground(UITheme.TEXT_MUTED);
            }
        });
        right.add(balanceLabel);
        right.add(new JLabel("|") {
            {
                setForeground(UITheme.TEXT_MUTED);
            }
        });
        right.add(logoutBtn);

        bar.add(right, BorderLayout.EAST);
        return bar;
    }

    // ── Sidebar ───────────────────────────────────────────────────────────────

    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(UITheme.BG_PANEL);
        sidebar.setPreferredSize(new Dimension(180, 0));
        sidebar.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, UITheme.BORDER_COLOR));

        sidebar.add(Box.createVerticalStrut(20));
        sidebar.add(navButton("📊  Market", "MARKET"));
        sidebar.add(navButton("💼  Portfolio", "PORTFOLIO"));
        sidebar.add(navButton("🔄  Trade", "TRADE"));
        sidebar.add(navButton("📈  Analytics", "ANALYTICS"));

        if (user.isAdmin()) {
            sidebar.add(Box.createVerticalStrut(8));
            sidebar.add(adminDivider());
            sidebar.add(navButton("⚙️  Admin", "ADMIN"));
        }

        sidebar.add(Box.createVerticalGlue());
        return sidebar;
    }

    private JButton navButton(String text, String panelKey) {
        JButton btn = new JButton(text);
        btn.setFont(UITheme.FONT_BODY);
        btn.setForeground(UITheme.TEXT_SECONDARY);
        btn.setBackground(UITheme.BG_PANEL);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setMaximumSize(new Dimension(180, 42));
        btn.setPreferredSize(new Dimension(180, 42));
        btn.setBorder(BorderFactory.createEmptyBorder(0, 16, 0, 0));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(UITheme.BG_HOVER);
                btn.setForeground(UITheme.TEXT_PRIMARY);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(UITheme.BG_PANEL);
                btn.setForeground(UITheme.TEXT_SECONDARY);
            }
        });
        btn.addActionListener(e -> showPanel(panelKey));
        return btn;
    }

    private JLabel adminDivider() {
        JLabel lbl = new JLabel("  ADMIN");
        lbl.setFont(UITheme.FONT_SMALL);
        lbl.setForeground(UITheme.GOLD);
        lbl.setMaximumSize(new Dimension(180, 24));
        lbl.setBorder(BorderFactory.createEmptyBorder(0, 16, 0, 0));
        return lbl;
    }

    // ── Navigation ────────────────────────────────────────────────────────────

    public void showPanel(String key) {
        cardLayout.show(contentArea, key);
        // Refresh data when switching panels
        switch (key) {
            case "MARKET" -> marketPanel.refresh();
            case "PORTFOLIO" -> {
                portfolioPanel.refresh();
                refreshBalanceLabel();
            }
            case "TRADE" -> {
                tradingPanel.refreshStocks();
                refreshBalanceLabel();
            }
            case "ANALYTICS" -> analyticsPanel.onShow();
            case "ADMIN" -> {
                if (adminPanel != null)
                    adminPanel.refresh();
            }
        }
    }

    // ── Simulator ─────────────────────────────────────────────────────────────

    private void initSimulator() {
        simulator.addListener(stock -> {
            SwingUtilities.invokeLater(() -> {
                marketPanel.onPriceUpdate(stock);
                analyticsPanel.onPriceUpdate(stock);
            });
        });
        simulator.start();

        // Stop simulator on window close
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                simulator.stop();
            }
        });
    }

    // ── Balance refresh ───────────────────────────────────────────────────────

    public void refreshUser() {
        User fresh = userService.refreshUser(user.getId());
        if (fresh != null) {
            this.user = fresh;
            refreshBalanceLabel();
            tradingPanel.setUser(user);
            portfolioPanel.setUser(user);
        }
    }

    private void refreshBalanceLabel() {
        User fresh = userService.refreshUser(user.getId());
        if (fresh != null) {
            this.user = fresh;
            balanceLabel.setText("💰 $" + String.format("%,.2f", user.getBalance()));
        }
    }

    // ── Logout ────────────────────────────────────────────────────────────────

    private void doLogout() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            simulator.stop();
            SwingUtilities.invokeLater(() -> {
                new LoginFrame().setVisible(true);
                dispose();
            });
        }
    }
}
