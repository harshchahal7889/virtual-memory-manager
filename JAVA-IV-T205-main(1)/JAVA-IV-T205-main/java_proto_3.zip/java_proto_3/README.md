# 📈 Stock Trading Simulation System

A complete Java desktop application simulating a real-time stock trading platform.
Built with **Java Swing** (UI), **JDBC + MySQL** (database), and **JFreeChart** (live graphs).

---

## 🖥️ Features

| Feature | Details |
|---------|---------|
| **Authentication** | Login / Register with MySQL-backed user accounts |
| **Live Market View** | All 20 stocks with color-coded price changes |
| **Buy / Sell Trading** | Real-time order execution with balance management |
| **Portfolio Dashboard** | Holdings, P&L per position, net worth summary |
| **Real-Time Charts** | JFreeChart time-series graph, auto-updates every 2-4s |
| **Analytics Panel** | Top Gainers, Top Losers, live price indicators |
| **Admin Panel** | Add / Edit / Delete stocks (admin users only) |
| **Price Simulator** | Background thread applies ±1% random price changes |

---

## 🗂️ Project Structure

```
StockTradingSystem/
├── pom.xml                          ← Maven build + dependencies
├── sql/
│   └── setup.sql                    ← Database schema + seed data
└── src/main/java/com/stocktrading/
    ├── Main.java                    ← Application entry point
    ├── model/
    │   ├── User.java
    │   ├── Stock.java
    │   ├── Transaction.java
    │   └── Portfolio.java
    ├── dao/
    │   ├── UserDAO.java
    │   ├── StockDAO.java
    │   ├── TransactionDAO.java
    │   └── PortfolioDAO.java
    ├── service/
    │   ├── UserService.java
    │   ├── StockService.java
    │   └── TradingService.java
    ├── simulator/
    │   └── StockPriceSimulator.java ← Background price simulation thread
    └── ui/
        ├── UITheme.java             ← Centralized design system
        ├── LoginFrame.java          ← Login / Register screen
        ├── MainFrame.java           ← Root window with sidebar navigation
        ├── MarketPanel.java         ← Live stock market table
        ├── TradingPanel.java        ← Buy / Sell order panel
        ├── PortfolioPanel.java      ← User holdings + P&L dashboard
        ├── AnalyticsPanel.java      ← JFreeChart real-time graph
        └── AdminPanel.java          ← Admin stock CRUD (admin only)
```

---

## ⚙️ Prerequisites

| Requirement | Version |
|-------------|---------|
| Java JDK    | 17 or above |
| MySQL Server | 8.0 or above |
| Maven        | 3.8+ (or use IntelliJ's bundled Maven) |
| IntelliJ IDEA | Community or Ultimate (recommended) |

---

## 🚀 Setup Instructions

### Step 1 — Clone / Extract the Project
Place the `StockTradingSystem` folder anywhere on your machine.

### Step 2 — Configure MySQL

1. Open MySQL Workbench (or any MySQL client).
2. Run the setup script:
   ```sql
   SOURCE /path/to/StockTradingSystem/sql/setup.sql;
   ```
   Or paste and run the file contents directly.

This creates:
- Database: `stock_trading_db`
- Tables: `users`, `stocks`, `portfolio`, `transactions`, `price_history`
- 20 pre-seeded stocks
- Two default accounts (see below)

### Step 3 — Update Database Credentials

Open `src/main/java/com/stocktrading/util/DatabaseConnection.java` and change:

```java
private static final String USERNAME = "root";   // ← your MySQL username
private static final String PASSWORD = "root";   // ← your MySQL password
```

### Step 4 — Import into IntelliJ IDEA

1. Open IntelliJ → **File → Open** → select the `StockTradingSystem` folder
2. IntelliJ detects `pom.xml` — click **"Load Maven Project"** when prompted
3. Wait for Maven to download dependencies (first time ~1-2 min)

### Step 5 — Run the Application

**Option A — IntelliJ:**
- Navigate to `src/main/java/com/stocktrading/Main.java`
- Right-click → **Run 'Main.main()'**

**Option B — Maven command line:**
```bash
cd StockTradingSystem
mvn clean package
java -jar target/StockTradingSystem-1.0.0.jar
```

---

## 🔑 Default Login Accounts

| Role  | Username | Password  | Starting Balance |
|-------|----------|-----------|-----------------|
| Admin | `admin`  | `admin123` | $999,999,999   |
| User  | `demo`   | `demo123`  | $100,000.00    |

---

## 📦 Dependencies (Auto-Downloaded by Maven)

| Library | Version | Purpose |
|---------|---------|---------|
| `mysql-connector-java` | 8.0.33 | JDBC driver for MySQL |
| `jfreechart` | 1.5.4 | Real-time time-series charts |

> **Manual JAR option** (if not using Maven):
> Download from:
> - https://mvnrepository.com/artifact/mysql/mysql-connector-java/8.0.33
> - https://mvnrepository.com/artifact/org.jfree/jfreechart/1.5.4
>
> Add both JARs to **File → Project Structure → Libraries** in IntelliJ.

---

## 🎮 How to Use

### Trading
1. Log in with the demo account
2. Go to **🔄 Trade** panel
3. Search for a stock (e.g., type "AAPL")
4. Enter quantity and click **▲ BUY** or **▼ SELL**

### Viewing Real-Time Charts
1. Navigate to **📈 Analytics**
2. Select any stock from the dropdown
3. Watch the price chart update every 2–4 seconds automatically

### Admin Panel
1. Log in as `admin / admin123`
2. Navigate to **⚙️ Admin**
3. Add new stocks, edit prices manually, or delete stocks

---

## 🔧 Architecture Notes

### Thread Model
```
Main Thread (EDT)         — All Swing UI updates
StockSimulator Thread     — Background price ticks (daemon thread)
  └─ Every 2-4 seconds:
       1. Applies ±1% random change per stock
       2. Writes new price to MySQL
       3. Notifies UI listeners
       4. UI listener calls SwingUtilities.invokeLater() for safe refresh
```

### Price Simulation Formula
```
changePercent = Random(-1%, +1%)
newPrice = oldPrice × (1 + changePercent)
newPrice = max(newPrice, $0.01)    // floor to prevent zero prices
```

### P&L Calculation
```
Invested Value  = avgBuyPrice × quantity
Current Value   = currentPrice × quantity
Profit / Loss   = currentValue - investedValue
P&L %           = (P&L / investedValue) × 100
```

---

## 🐛 Troubleshooting

| Problem | Solution |
|---------|----------|
| `ClassNotFoundException: com.mysql.cj.jdbc.Driver` | Add mysql-connector JAR to classpath / reload Maven |
| `Connection refused` on start | Ensure MySQL is running on port 3306 |
| `Access denied for user 'root'` | Update credentials in `DatabaseConnection.java` |
| `Table doesn't exist` | Run `sql/setup.sql` first |
| Charts not showing | Ensure `jfreechart-1.5.4.jar` is on classpath |
| Blank UI panels | Check console for SQL exceptions |

---

## 📝 License
Educational / personal use. Built for learning Java Swing, JDBC, and concurrent programming patterns.
